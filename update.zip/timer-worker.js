// Worker chỉ để đếm giờ: timer trong worker không bị Chrome giảm tốc khi tab bảng điều khiển nằm ở nền.
self.onmessage = (e) => {
  const { id, ms } = e.data;
  setTimeout(() => self.postMessage({ id }), ms);
};
