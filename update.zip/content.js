(() => {
  if (window.__vcAutoLoaded) return;
  window.__vcAutoLoaded = true;

  const norm = (s) => (s || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const incoming = {}; // id -> các mảnh của file đang nhận

  /* ---------- tiện ích ---------- */
  function setNativeValue(el, value) {
    const proto =
      el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype
      : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function b64ToBytes(b64) {
    const bin = atob(b64);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }

  const leaf = (e) => e.children.length === 0;
  const ownText = (e) => [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim();

  /* ---------- danh sách page ---------- */
  function pageSection() {
    const heads = [...document.querySelectorAll('h1,h2,h3,h4,div,span,p')]
      .filter((e) => leaf(e) && norm(e.textContent) === 'select pages');
    for (const h of heads) {
      let el = h;
      for (let i = 0; i < 8 && el; i++) {
        el = el.parentElement;
        if (el && el.querySelector('input[type=checkbox],[role=checkbox]')) return el;
      }
    }
    return document;
  }

  const isChecked = (cb) => cb.checked === true || cb.getAttribute('aria-checked') === 'true';

  function listPages() {
    const boxes = [...pageSection().querySelectorAll('input[type=checkbox],[role=checkbox]')];
    return boxes
      .map((cb) => {
        let row = cb;
        let name = '';
        for (let i = 0; i < 6 && row.parentElement; i++) {
          row = row.parentElement;
          const t = (row.innerText || '').trim();
          if (t && t.length < 200) { name = t.split('\n')[0].trim(); break; }
        }
        return { cb, row, name, checked: isChecked(cb) };
      })
      .filter((p) => p.name && norm(p.name) !== 'select all');
  }

  // Số page tổng theo dòng "0 of 37 selected" và khung cuộn chứa danh sách page.
  function totalCount() {
    const m = /of\s+(\d+)\s+selected/i.exec(pageSection().innerText || '');
    return m ? +m[1] : 0;
  }
  function scrollBox() {
    const first = pageSection().querySelector('input[type=checkbox],[role=checkbox]');
    let el = first && first.parentElement;
    while (el && el !== document.body) {
      const st = getComputedStyle(el);
      if (/(auto|scroll)/.test(st.overflowY) && el.scrollHeight > el.clientHeight + 4) return el;
      el = el.parentElement;
    }
    return null;
  }
  // Danh sách chỉ render phần đang thấy: kéo từ từ xuống, thấy page nào cần thì tick luôn.
  async function scrollTick(left, ticked) {
    const box = scrollBox();
    if (!box) return;
    box.scrollTop = 0;
    await sleep(250);
    for (let guard = 0; guard < 80 && left.size; guard++) {
      for (const p of listPages()) {
        for (const [typed, n] of left) {
          if (norm(p.name) !== n) continue;
          if (!p.checked) {
            p.cb.click(); await sleep(150);
            if (!isChecked(p.cb)) { p.row.click(); await sleep(150); }
          }
          ticked.push({ typed, actual: p.name });
          left.delete(typed);
          break;
        }
      }
      if (!left.size) break;
      const before = box.scrollTop;
      box.scrollTop += Math.max(40, box.clientHeight * 0.8);
      await sleep(250);
      if (box.scrollTop === before) break;
    }
  }

  async function tickPages(names) {
    const pages = listPages();
    const target = new Map(); // page -> tên người dùng gõ
    const missing = [];
    for (const typed of names) {
      const n = norm(typed);
      let m = pages.find((p) => norm(p.name) === n);
      if (!m) {
        const c = pages.filter((p) => norm(p.name).includes(n));
        if (c.length === 1) m = c[0];
      }
      if (m) target.set(m, typed); else missing.push(typed);
    }
    const ticked = [];
    for (const p of pages) {
      const should = target.has(p);
      if (should !== p.checked) {
        try { p.row.scrollIntoView({ block: 'nearest' }); } catch (e) { /* bỏ qua */ }
        p.cb.click();
        await sleep(150);
        if (isChecked(p.cb) !== should) { p.row.click(); await sleep(150); }
      }
      if (should) ticked.push({ typed: target.get(p), actual: p.name });
    }
    if (missing.length && totalCount() > pages.length) {
      const left = new Map(missing.map((m) => [m, norm(m)]));
      missing.length = 0;
      await scrollTick(left, ticked);
      for (const t of left.keys()) missing.push(t);
    }
    return { ticked, missing, total: Math.max(pages.length, totalCount()) };
  }

  /* ---------- upload file ---------- */
  function findInput(slot) {
    const all = [...document.querySelectorAll('input[type=file]')];
    const vid = all.filter((i) => /video/i.test(i.accept || ''));
    let video, cover, card2;
    if (vid.length) {
      const img = all.filter((i) => !vid.includes(i));
      video = vid[0]; cover = img[0]; card2 = img[1];
    } else {
      [video, cover, card2] = all;
    }
    return { video, cover, card2 }[slot] || null;
  }

  function findDropzone(slot) {
    const re = { video: /^upload video$/i, cover: /^upload cover image$/i, card2: /^upload image$/i }[slot];
    const el = [...document.querySelectorAll('div,span,p,label')].find((e) => leaf(e) && re.test((e.textContent || '').trim()));
    return el ? el.parentElement : null;
  }

  function attachFile(slot, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    const input = findInput(slot);
    if (input) {
      input.files = dt.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return 'input';
    }
    const zone = findDropzone(slot);
    if (!zone) throw new Error('Không tìm thấy ô upload "' + slot + '" trên trang');
    for (const type of ['dragenter', 'dragover', 'drop']) {
      zone.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt }));
    }
    return 'drop';
  }

  /* ---------- điền ô chữ ---------- */
  function findField(phRe, labelText) {
    const els = [...document.querySelectorAll('input:not([type=file]):not([type=checkbox]),textarea')];
    const byPh = els.find((e) => phRe.test(e.placeholder || ''));
    if (byPh) return byPh;
    const lab = [...document.querySelectorAll('label,div,span,p')]
      .find((e) => leaf(e) && norm(e.textContent).replace(/\s*\*$/, '') === labelText);
    if (lab) {
      let c = lab;
      for (let i = 0; i < 4 && c; i++) {
        c = c.parentElement;
        const f = c && c.querySelector('input:not([type=file]):not([type=checkbox]),textarea');
        if (f) return f;
      }
    }
    return null;
  }

  function fillText(m) {
    const spec = [
      ['description', m.description, /post description/i, 'description', 'Description'],
      ['title1', m.title1, /title for the video card/i, 'card 1 title', 'Card 1 Title'],
      ['title2', m.title2, /title for the image card/i, 'card 2 title', 'Card 2 Title'],
      ['link', m.link, /^https?:\/\//i, 'link url', 'Link URL'],
    ];
    const done = [];
    for (const [key, val, ph, label, vn] of spec) {
      if (val === null || val === undefined || val === '') continue;
      const el = findField(ph, label);
      if (!el) throw new Error('Không tìm thấy ô "' + vn + '" trên trang');
      setNativeValue(el, val);
      done.push(key);
    }
    return done;
  }

  /* ---------- Button Type = Open Link ---------- */
  async function ensureOpenLink() {
    const openRe = /open\s*link/i;
    const sel = [...document.querySelectorAll('select')].find((s) => [...s.options].some((o) => openRe.test(o.text + o.value)));
    if (sel) {
      const before = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '';
      if (openRe.test(before)) return { before, changed: false };
      const opt = [...sel.options].find((o) => openRe.test(o.text + o.value));
      setNativeValue(sel, opt.value);
      await sleep(250);
      return { before, changed: true };
    }
    const lab = [...document.querySelectorAll('label,div,span,p')].find((e) => leaf(e) && norm(e.textContent) === 'button type');
    if (!lab) throw new Error('Không tìm thấy ô Button Type');
    let c = lab;
    let trigger = null;
    for (let i = 0; i < 4 && c && !trigger; i++) {
      c = c.parentElement;
      trigger = c && c.querySelector('select,button,[role=combobox],[role=button]');
    }
    if (!trigger) throw new Error('Không tìm thấy nút chọn của Button Type');
    const cur = (trigger.innerText || trigger.textContent || '').trim();
    if (openRe.test(cur)) return { before: cur, changed: false };
    trigger.click();
    await sleep(400);
    const opt = [...document.querySelectorAll('[role=option],li,button,div,span')]
      .find((e) => leaf(e) && /^open\s*link$/i.test((e.textContent || '').trim()));
    if (!opt) throw new Error('Mở được Button Type nhưng không thấy lựa chọn "Open Link"');
    opt.click();
    await sleep(300);
    return { before: cur, changed: true };
  }

  /* ---------- nút Post ---------- */
  function postButton() {
    return [...document.querySelectorAll('button')].find((b) => /post video carousel/i.test(b.textContent || ''));
  }
  function postState() {
    const b = postButton();
    if (!b) return { found: false };
    return { found: true, disabled: b.disabled || b.getAttribute('aria-disabled') === 'true', text: b.textContent.trim() };
  }

  /* ---------- đọc Results ---------- */
  const parseRgb = (s) => {
    const m = /rgba?\(([^)]+)\)/.exec(s || '');
    if (!m) return null;
    const p = m[1].split(',').map((x) => parseFloat(x));
    if (p.length >= 4 && p[3] === 0) return null;
    return p.slice(0, 3);
  };
  const hue = (rgb) => {
    if (!rgb) return null;
    const [r, g, b] = rgb;
    if (r - g >= 8 && r - b >= 8) return 'red';
    if (g - r >= 5 && g - b >= 5) return 'green';
    return null;
  };
  const colorOf = (el) => {
    const cs = getComputedStyle(el);
    return hue(parseRgb(cs.backgroundColor)) || hue(parseRgb(cs.borderTopColor));
  };
  const textRed = (el) => {
    const rgb = parseRgb(getComputedStyle(el).color);
    return !!rgb && rgb[0] > 140 && rgb[1] < 100 && rgb[2] < 100;
  };

  // Mục Results của FaceBot giữ cả lịch sử cũ (kết quả của các lần đăng trước, cùng tên page).
  // Nên trước khi bấm Post tool chụp lại các dòng đang có (snapResults), sau đó chỉ đọc những dòng MỚI xuất hiện.
  let oldTotal = 0;
  let oldRows = {}; // tên page đã chuẩn hoá -> mảng chữ của các dòng cũ
  function resultRows(names) {
    const heads = [...document.querySelectorAll('*')].filter((e) => /^results$/i.test(ownText(e)) || (leaf(e) && /^results$/i.test((e.textContent || '').trim())));
    const hdr = heads[0];
    if (!hdr) return { found: false, byName: {}, total: 0 };
    // Tiêu đề Results có thẻ đếm kiểu "1 success" / "1 failed": chỉ khi thẻ này > 0 mới có kết quả thật.
    let total = 0, badge = '';
    for (let el = hdr, i = 0; el && i < 3 && !total; el = el.parentElement, i++) {
      const tt = (el.innerText || '').slice(0, 200);
      const ok = +((tt.match(/(\d+)\s*success/i) || [])[1] || 0);
      const bad = +((tt.match(/(\d+)\s*(?:failed|fail|error)/i) || [])[1] || 0);
      if (ok + bad > 0) { total = ok + bad; badge = ok + ' success, ' + bad + ' failed'; }
    }
    const wants = names.map(norm);
    let container = hdr;
    for (let i = 0; i < 8 && container.parentElement; i++) {
      container = container.parentElement;
      const t = norm(container.innerText || '');
      if (wants.some((w) => t.includes(w))) break;
    }
    const all = [...container.querySelectorAll('*')];
    const byName = {};
    for (const name of names) {
      const n = norm(name);
      // các phần tử nhỏ nhất có chứa tên page (không có con nào chứa tên đó nữa)
      const mins = all.filter((el) => norm(el.innerText || '').includes(n) && ![...el.children].some((c) => norm(c.innerText || '').includes(n)));
      const rows = [];
      for (const best of mins) {
        let row = best;
        while (row.parentElement && row.parentElement !== container) {
          const pt = norm(row.parentElement.innerText || '');
          if (/^results\b/.test(pt) || wants.some((o) => o !== n && !n.includes(o) && pt.includes(o))) break;
          row = row.parentElement;
        }
        if (!rows.includes(row)) rows.push(row);
      }
      byName[name] = rows;
    }
    return { found: true, byName, total, badge };
  }
  function snapResults(names) {
    const r = resultRows(names);
    oldRows = {};
    oldTotal = r.total || 0;
    for (const name of names) oldRows[name] = (r.byName[name] || []).map((row) => norm(row.innerText || ''));
    return { found: r.found, count: Object.values(oldRows).reduce((a, x) => a + x.length, 0) };
  }
  function readResults(names, final) {
    const r = resultRows(names);
    if (!r.found) return { found: false, rows: names.map((name) => ({ name, status: 'pending' })) };
    // chưa có kết quả mới nào (thẻ đếm chưa tăng) thì video còn đang tải lên: tất cả vẫn là "đang chờ"
    if (!r.total) return { found: true, rows: names.map((name) => ({ name, status: 'pending' })), badge: r.badge };
    const errRe = /error|fail|lỗi|unable|invalid|denied|not allowed|couldn'?t|cannot|went wrong|try again/i;
    const rows = names.map((name) => {
      const olds = oldRows[name] || [];
      const allRows = r.byName[name] || [];
      let fresh = allRows.filter((row) => !olds.includes(norm(row.innerText || '')));
      if (!fresh.length && allRows.length > olds.length) fresh = allRows; // đăng lại: dòng mới trùng chữ với dòng cũ nhưng số dòng tăng
      // đọc lần cuối sau khi hết giờ chờ: dòng LỖI giống hệt dòng lỗi cũ thì coi là lỗi mới (dòng thành công cũ thì không dám coi là mới)
      const lastTry = final && !fresh.length && allRows.length;
      if (!fresh.length && !lastTry) return { name, status: 'pending' };
      const row = lastTry ? allRows[0] : fresh[0];
      const text = (row.innerText || '').trim();
      const hasView = /view post/i.test(text);
      let color = colorOf(row);
      if (!color) {
        const kids = [...row.querySelectorAll('*')].slice(0, 15);
        color = kids.map(colorOf).find(Boolean) || null;
        if (!color && (textRed(row) || kids.some(textRed))) color = 'red';
      }
      const message = text.replace(name, '').replace(/view post/i, '').replace(/\s+/g, ' ').trim();
      let status = 'pending';
      if (color === 'red') status = 'error';
      else if (hasView || color === 'green') status = 'success';
      else if (errRe.test(text)) status = 'error';
      if (lastTry && status !== 'error') return { name, status: 'pending' };
      return { name, status, message, text: text.replace(/\s+/g, ' ').slice(0, 140) };
    });
    return { found: true, rows };
  }

  /* ---------- nhận lệnh từ bảng điều khiển ---------- */
  async function handle(msg) {
    switch (msg.cmd) {
      case 'ping': return 'pong';
      case 'listPages': return listPages().map((p) => ({ name: p.name, checked: p.checked }));
      case 'tickPages': return tickPages(msg.names);
      case 'fileChunk': {
        const parts = incoming[msg.id] || (incoming[msg.id] = []);
        parts[msg.index] = b64ToBytes(msg.b64);
        if (msg.index === msg.total - 1) {
          const f = new File(parts, msg.name, { type: msg.mime });
          delete incoming[msg.id];
          return { done: true, how: attachFile(msg.slot, f), size: f.size };
        }
        return { done: false };
      }
      case 'fillText': return fillText(msg);
      case 'ensureOpenLink': return ensureOpenLink();
      case 'postState': return postState();
      case 'clickPost': {
        const b = postButton();
        if (!b) throw new Error('Không tìm thấy nút "Post Video Carousel"');
        if (b.disabled) throw new Error('Nút Post chưa bấm được');
        b.click();
        return true;
      }
      case 'snapResults': return snapResults(msg.names);
      case 'readResults': return readResults(msg.names, msg.final);
      default: throw new Error('Lệnh không hợp lệ: ' + msg.cmd);
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    handle(msg)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  });
})();
