'use strict';

const $ = (id) => document.getElementById(id);
const FB_URL = 'https://www.facebook.com/';
const TOOL_URL = 'https://fb0t.com/securebot/tools/content/video-carousel';
const VIDEO_RE = /\.(mp4|mov|mkv|avi|webm|m4v)$/i;
const IMAGE_RE = /\.(jpe?g|png|webp)$/i;

const DEFAULTS = {
  pagesText: '',
  pageMode: 'all',
  coverMode: 'auto', coverRatio: '1:1',
  card2Mode: 'auto', card2Ratio: '1:1',
  title1: '', title2: '',
  linksText: '',
  runMode: 'now', timesText: '08:00\n16:00',
  checkNick: true,
  moveFailed: false,
  alertMode: 'notify',
  soundFile: '1',
  maxFail: 4,
  instName: '',
  useNewDir: false,
  newMax: 3,
  dailyLimit: 0,
  intervalMin: 20,
  useActive: false,
  activeFrom: '07:00',
  activeTo: '23:00',
};

let S = { ...DEFAULTS };
let stats = { success: 0, fail: 0, runs: 0, byPage: {} };
let history = {};          // "tên file|dung lượng" -> [tên page đã chuẩn hoá]
let firstSeen = {};        // key video -> lúc tool thấy lần đầu (ms)
let videoFails = {};       // key video -> số lần lỗi (đã tính theo quy tắc)
let failDirHandle = null;
let failedVideos = [];     // { time, video, page, message }
let state = { pageIdx: 0, linkIdx: 0 };
let dirHandle = null;
const fixed = { cover: null, card2: null }; // { blob, name }
const run = { active: false, stop: false, tabId: null, curVideo: null, claim: null };
let newDirHandle = null; // thư mục video mới (tuỳ chọn)

class Stop extends Error {}
class NickError extends Error {}

/* ====================== tiện ích ====================== */
const norm = (s) => (s || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
const lines = (t) => (t || '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
const pad = (n) => String(n).padStart(2, '0');
const nowStr = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); };
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const stem = (name) => name.replace(/\.[^.]+$/, '');

const logBuf = [];
function log(msg, kind = '') {
  logBuf.push(nowStr() + (kind === 'err' ? ' [LỖI] ' : kind === 'warn' ? ' [CHÚ Ý] ' : ' ') + msg);
  if (logBuf.length > 600) logBuf.shift();
  const box = $('log');
  const d = document.createElement('div');
  if (kind) d.className = kind;
  const t = document.createElement('span');
  t.className = 't';
  t.textContent = nowStr();
  d.append(t, document.createTextNode(msg));
  box.prepend(d);
  while (box.children.length > 300) box.lastChild.remove();
}

function setStatus(text, kind = '') {
  const el = $('statusText');
  el.textContent = text;
  el.className = 'status ' + kind;
  const bd = $('stateBadge');
  if (bd) {
    let cls = 'idle', t = 'SẴN SÀNG';
    if (/^Hết video/i.test(text)) { cls = 'err'; t = 'HẾT VIDEO'; }
    else if (/^Xong/i.test(text)) { cls = 'done'; t = kind === 'err' ? 'XONG, CÓ PAGE LỖI' : 'XONG'; }
    else if (kind === 'err') { cls = 'err'; t = 'LỖI'; }
    else if (/dừng/i.test(text)) { cls = 'stop'; t = /^Đang dừng/i.test(text) ? 'ĐANG DỪNG' : 'ĐÃ DỪNG'; }
    else if (/chờ (mốc|lần)/i.test(text)) { cls = 'run'; t = 'ĐANG CHỜ GIỜ'; }
    else if (run.active || kind === 'busy') { cls = 'run'; t = 'ĐANG CHẠY'; }
    bd.className = 'badge ' + cls; bd.textContent = t;
  }
}

function showBanner(text) { const b = $('banner'); b.textContent = text; b.hidden = false; }
function hideBanner() { $('banner').hidden = true; }

// Chỉ báo khi nick die. Đoạn âm thanh nằm sẵn trong thư mục extension.
const SOUND_IDS = ['1', '2', '3'];
let currentAudio = null;
function playNickSound(times = 1, id) {
  if (id !== 'out') id = SOUND_IDS.includes(id) ? id : (SOUND_IDS.includes(S.soundFile) ? S.soundFile : '1');
  try { if (currentAudio) currentAudio.pause(); } catch (e) { /* bỏ qua */ }
  let left = times;
  const a = new Audio(chrome.runtime.getURL(id === 'out' ? 'sounds/het-video.mp3' : 'sounds/nick-die-' + id + '.mp3'));
  currentAudio = a;
  a.onended = () => { if (--left > 0) { a.currentTime = 0; a.play().catch(() => {}); } };
  a.play().catch((e) => log('Không phát được âm thanh: ' + e.message, 'warn'));
}

function notify(title, message, soundId) {
  try {
    chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: ((S.instName || '').trim() ? '[' + S.instName.trim() + '] ' : '') + title, message: String(message).slice(0, 250) });
  } catch (e) { /* bỏ qua */ }
  if (S.alertMode === 'sound') playNickSound(2, soundId);
}

/* ====================== lưu trữ ====================== */
function idbOpen() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('vc-auto', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function idbGet(k) {
  const db = await idbOpen();
  return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
}
async function idbSet(k, v) {
  const db = await idbOpen();
  return new Promise((res, rej) => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
}

const saveSettings = debounce(() => chrome.storage.local.set({ settings: S }), 250);
const saveStats = () => chrome.storage.local.set({ stats });
const saveHistory = async () => { await chrome.storage.local.set({ history }); await flushResultFile(); };
const saveState = () => chrome.storage.local.set({ state });
const saveFailedVideos = () => chrome.storage.local.set({ failedVideos });

/* ====================== giao diện <-> cài đặt ====================== */
const radioVal = (name) => (document.querySelector(`input[name="${name}"]:checked`) || {}).value;
const setRadio = (name, v) => { const r = document.querySelector(`input[name="${name}"][value="${v}"]`); if (r) r.checked = true; };

function readUI() {
  S.pagesText = $('pagesText').value;
  S.pageMode = radioVal('pageMode') || 'all';
  S.coverMode = radioVal('coverMode') || 'auto';
  S.coverRatio = $('coverRatio').value;
  S.card2Mode = radioVal('card2Mode') || 'auto';
  S.card2Ratio = $('card2Ratio').value;
  S.title1 = $('title1').value;
  S.title2 = $('title2').value;
  S.linksText = $('linksText').value;
  S.runMode = radioVal('runMode') || 'now';
  S.timesText = $('timesText').value;
  S.checkNick = $('checkNick').checked;
  S.moveFailed = $('moveFailed').checked;
  S.alertMode = radioVal('alertMode') || 'notify';
  S.soundFile = radioVal('soundFile') || '1';
  S.instName = $('instName').value.trim();
  S.useNewDir = $('useNewDir').checked;
  S.newMax = Math.min(50, Math.max(1, parseInt($('newMax').value, 10) || 3));
  S.maxFail = Math.min(20, Math.max(1, parseInt($('maxFail').value, 10) || 4));
  S.dailyLimit = Math.min(200, Math.max(0, parseInt($('dailyLimit').value, 10) || 0));
  S.intervalMin = Math.min(1440, Math.max(1, parseInt($('intervalMin').value, 10) || 20));
  S.useActive = $('useActive').checked;
  S.activeFrom = $('activeFrom').value || '07:00';
  S.activeTo = $('activeTo').value || '23:00';
}

function applyUI() {
  $('pagesText').value = S.pagesText;
  setRadio('pageMode', S.pageMode);
  setRadio('coverMode', S.coverMode);
  $('coverRatio').value = S.coverRatio;
  setRadio('card2Mode', S.card2Mode);
  $('card2Ratio').value = S.card2Ratio;
  $('title1').value = S.title1;
  $('title2').value = S.title2;
  $('linksText').value = S.linksText;
  setRadio('runMode', S.runMode);
  $('timesText').value = S.timesText;
  $('checkNick').checked = S.checkNick;
  $('moveFailed').checked = S.moveFailed;
  setRadio('alertMode', S.alertMode);
  setRadio('soundFile', S.soundFile);
  $('instName').value = S.instName || '';
  $('useNewDir').checked = S.useNewDir;
  $('newMax').value = S.newMax;
  $('maxFail').value = S.maxFail;
  $('dailyLimit').value = S.dailyLimit;
  $('intervalMin').value = S.intervalMin;
  $('useActive').checked = S.useActive;
  $('activeFrom').value = S.activeFrom;
  $('activeTo').value = S.activeTo;
  toggleRows();
}

function toggleRows() {
  // Tỉ lệ ảnh dùng cho chế độ tự cắt, và cho chế độ thumb khi không có ảnh thì quay về tự cắt.
  $('coverAutoRow').hidden = S.coverMode === 'fixed';
  $('coverFixedRow').hidden = S.coverMode !== 'fixed';
  $('card2AutoRow').hidden = S.card2Mode === 'fixed';
  $('card2FixedRow').hidden = S.card2Mode !== 'fixed';
  $('timesWrap').hidden = S.runMode !== 'schedule';
  $('moveWrap').hidden = !S.moveFailed;
  $('skipRow').hidden = S.pageMode !== 'rotate';
  $('intervalWrap').hidden = S.runMode !== 'interval';
  $('activeWrap').hidden = !S.useActive;
  $('newDirWrap').hidden = !S.useNewDir;
}

function onChange() { readUI(); toggleRows(); updateResultFileName(); saveSettings(); }

function bindFixedImage(slot, inputId, nameId) {
  $(inputId).addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    fixed[slot] = { blob: f, name: f.name };
    await idbSet('fixed-' + slot, fixed[slot]);
    $(nameId).textContent = 'Đã chọn: ' + f.name;
  });
}

/* ====================== thư mục video ====================== */
async function listVideos() {
  const out = [];
  for await (const [name, h] of dirHandle.entries()) {
    if (h.kind === 'file' && VIDEO_RE.test(name)) {
      const f = await h.getFile();
      out.push({ name, size: f.size, mod: f.lastModified, key: name + '|' + f.size, handle: h, dir: dirHandle });
    }
  }
  // Mỗi lần quét ghi nhớ lúc tool thấy video lần đầu. Video bỏ vào sau cùng được đăng trước.
  let dirty = false;
  const nowMs = Date.now();
  for (const v of out) if (!firstSeen[v.key]) { firstSeen[v.key] = nowMs; dirty = true; }
  if (oldBefore < 0) { oldBefore = nowMs; chrome.storage.local.set({ oldBefore, oldBeforeV: 2 }); } // lần quét đầu: video đang có đều là video cũ
  if (dirty) {
    const keys = Object.keys(firstSeen);
    if (keys.length > 5000) { const live = new Set(out.map((v) => v.key)); for (const k of keys) if (!live.has(k)) delete firstSeen[k]; }
    chrome.storage.local.set({ firstSeen });
  }
  out.sort((a, b) => (firstSeen[b.key] - firstSeen[a.key]) || (b.mod - a.mod) || a.name.localeCompare(b.name, 'vi', { numeric: true }));
  if (S.useNewDir && newDirHandle) {
    const fresh = await listNewVideos();
    return fresh.concat(out); // video mới (theo tên) đứng trước, video cũ sau
  }
  return out;
}

// Tìm ảnh thumb có cùng tên với video (khác đuôi), ví dụ abc.mp4 -> abc.jpg
async function findThumb(videoName) {
  const base = norm(stem(videoName));
  for await (const [name, h] of dirHandle.entries()) {
    if (h.kind === 'file' && IMAGE_RE.test(name) && norm(stem(name)) === base) return await h.getFile();
  }
  return null;
}

let lastRenderDay = '';
let lastFolderRefresh = 0;
async function refreshFolderThrottled() {
  if (Date.now() - lastFolderRefresh < 20000) return;
  lastFolderRefresh = Date.now();
  try { await refreshFolderInfo(); } catch (e) { /* bỏ qua */ }
}
async function refreshFolderInfo() {
  lastFolderRefresh = Date.now();
  $('btnPerm').hidden = true;
  if (!dirHandle) { $('folderInfo').textContent = 'Chưa chọn thư mục.'; $('stVideos').textContent = '0'; $('stNew').textContent = '0'; return; }
  const perm = await dirHandle.queryPermission({ mode: 'read' });
  if (perm !== 'granted') {
    $('folderInfo').textContent = 'Thư mục: ' + dirHandle.name + '. Cần cấp lại quyền đọc (bấm nút bên trên).';
    $('btnPerm').hidden = false;
    return;
  }
  const vids = await listVideos();
  const nNew = vids.filter((v) => v.isNew).length;
  $('folderInfo').textContent = 'Thư mục: ' + dirHandle.name + ', có ' + (vids.length - nNew) + ' video' + (S.useNewDir ? '. Thư mục video mới có ' + nNew + ' video.' : '.');
  $('stVideos').textContent = String(vids.length - nNew);
  $('stNew').textContent = String(nNew);
  $('stNewBox').hidden = !S.useNewDir;
  $('stOldLabel').textContent = S.useNewDir ? 'Video thư mục cũ' : 'Video trong thư mục';
}

async function pickFolder() {
  try {
    const h = await window.showDirectoryPicker({ mode: 'read', id: 'vc-videos' });
    dirHandle = h;
    await idbSet('dir', h);
    await refreshFolderInfo();
    await refreshFailInfo();
    await refreshDaily();
  } catch (e) { if (e.name !== 'AbortError') log('Không chọn được thư mục: ' + e.message, 'err'); }
}

async function regrantPermission() {
  if (!dirHandle) return;
  await dirHandle.requestPermission({ mode: 'read' });
  await refreshFolderInfo();
}

/* ====================== thư mục video mới (dùng chung nhiều extension) ====================== */
// Mỗi extension ghi file video-moi-(tên).txt trong thư mục video mới, mọi extension đều đọc tất cả các file đó để cộng số lần đăng.
// Mỗi dòng: giờ | tên video | dung lượng | tên extension | DANG (đang đăng, giữ chỗ) / THÀNH CÔNG / CHƯA RÕ / LỖI
const SHARED_PREFIX = 'video-moi-';
const sharedWho = () => instTag() + '#' + chrome.runtime.id.slice(0, 6); // mã extension giữ cho mỗi bản một file riêng dù trùng tên
const CLAIM_MS = 20 * 60 * 1000;
const newPermOk = async () => !!newDirHandle && (await newDirHandle.queryPermission({ mode: 'read' })) === 'granted';

async function sharedLines() {
  const out = [];
  for await (const [name, h] of newDirHandle.entries()) {
    if (h.kind !== 'file' || !name.startsWith(SHARED_PREFIX) || !name.endsWith('.txt')) continue;
    try {
      const t = await (await h.getFile()).text();
      for (const line of t.split(/\r?\n/)) {
        const c = line.split(' | ').map((x) => x.trim());
        if (c.length >= 5) out.push({ t: c[0], key: c[1] + '|' + c[2], who: c[3], st: c[4].toUpperCase() });
      }
    } catch (e) { /* file đang được extension khác ghi, bỏ qua lần này */ }
  }
  return out;
}
// done: số lần đã đăng xong (thành công hoặc chưa rõ), claims: số lượt đang đăng của extension khác (chưa quá 20 phút)
function tallyNew(lines, key) {
  const me = sharedWho();
  let done = 0;
  const pending = new Map();
  for (const l of lines) {
    if (l.key !== key) continue;
    const pk = l.who;
    if (l.st === 'DANG') (pending.get(pk) || pending.set(pk, []).get(pk)).push(new Date(l.t.replace(' ', 'T')).getTime());
    else {
      if (l.st === 'THÀNH CÔNG' || l.st === 'CHƯA RÕ') done++;
      const arr = pending.get(pk);
      if (arr && arr.length) arr.shift();
    }
  }
  let claims = 0;
  const now = Date.now();
  for (const [who, arr] of pending) if (who !== me) claims += arr.filter((t) => now - t < CLAIM_MS).length;
  return { done, claims };
}
async function sharedAppend(video, st) {
  if (!newDirHandle) return;
  const fname = SHARED_PREFIX + sharedWho() + '.txt';
  try {
    let old = '';
    try { old = await (await (await newDirHandle.getFileHandle(fname)).getFile()).text(); } catch (e) { old = ''; }
    const line = [stamp(), clean(video.name), video.size, clean(sharedWho()), st].join(' | ');
    const w = await (await newDirHandle.getFileHandle(fname, { create: true })).createWritable();
    await w.write(old + (old && !old.endsWith('\n') ? '\n' : '') + line + '\n');
    await w.close();
  } catch (e) { log('Không ghi được file dùng chung ' + fname + ': ' + e.message, 'warn'); }
}
const moveWarned = new Set();
async function listNewVideos() {
  const out = [];
  let seenDirty = false;
  try {
    if (!(await newPermOk())) return out;
    const lines = await sharedLines();
    const rw = (await hasRW(newDirHandle)) && (await hasRW(dirHandle));
    for await (const [name, h] of newDirHandle.entries()) {
      if (h.kind !== 'file' || !VIDEO_RE.test(name)) continue;
      const f = await h.getFile();
      const v = { name, size: f.size, mod: f.lastModified, key: name + '|' + f.size, handle: h, dir: newDirHandle, isNew: true };
      if (!firstSeen[v.key]) { firstSeen[v.key] = Date.now(); seenDirty = true; }
      const t = tallyNew(lines, v.key);
      if (t.done >= S.newMax) {
        // đủ số lần: chuyển sang thư mục cũ, không đăng nữa
        if (!rw) {
          if (!moveWarned.has(v.key)) { moveWarned.add(v.key); log('Video mới "' + name + '" đã đăng đủ ' + S.newMax + ' lần nhưng chưa có quyền ghi thư mục để chuyển sang thư mục cũ. Bấm Bắt đầu và chọn Cho phép.', 'warn'); }
        } else {
          try { await moveFileTo(v, dirHandle); log('Video mới "' + name + '" đã đăng đủ ' + S.newMax + ' lần, đã chuyển sang thư mục cũ', 'ok'); }
          catch (e) { if (!moveWarned.has(v.key)) { moveWarned.add(v.key); log('Chưa chuyển được video mới "' + name + '" sang thư mục cũ: ' + e.message, 'warn'); } }
        }
        continue;
      }
      if (t.done + t.claims >= S.newMax) continue; // các extension khác đang đăng đủ số lần rồi
      out.push(v);
    }
  } catch (e) { log('Không quét được thư mục video mới: ' + e.message, 'warn'); }
  if (seenDirty) chrome.storage.local.set({ firstSeen });
  // video mới bỏ vào gần nhất đăng trước
  out.sort((a, b) => ((firstSeen[b.key] || 0) - (firstSeen[a.key] || 0)) || (b.mod - a.mod) || a.name.localeCompare(b.name, 'vi', { numeric: true }));
  return out;
}
async function claimNew(video) {
  run.claim = video;
  await sharedAppend(video, 'DANG');
}
async function releaseClaim() {
  if (run.claim) { const v = run.claim; run.claim = null; await sharedAppend(v, 'LỖI'); }
}
// Ghi kết quả của một lượt đăng video mới vào file dùng chung, rồi chuyển video nếu đã đủ số lần.
async function finishNew(video, res) {
  if (!video || !video.isNew) return;
  run.claim = null;
  let wrote = false;
  for (const r of res) {
    if (r.status === 'success') { await sharedAppend(video, 'THÀNH CÔNG'); wrote = true; }
    else if (r.unread) { await sharedAppend(video, 'CHƯA RÕ'); wrote = true; }
  }
  if (!wrote) await sharedAppend(video, 'LỖI'); // nhả chỗ đã giữ
  try {
    const t = tallyNew(await sharedLines(), video.key);
    if (t.done >= S.newMax && !((await hasRW(newDirHandle)) && (await hasRW(dirHandle)))) {
      log('Video mới "' + video.name + '" đã đăng đủ ' + S.newMax + ' lần nhưng chưa có quyền ghi thư mục để chuyển. Bấm Bắt đầu và chọn Cho phép.', 'warn');
    }
    if (t.done >= S.newMax && (await hasRW(newDirHandle)) && (await hasRW(dirHandle))) {
      await moveFileTo(video, dirHandle);
      log('Video mới "' + video.name + '" đã đăng đủ ' + S.newMax + ' lần, đã chuyển sang thư mục cũ', 'ok');
    }
  } catch (e) { log('Chưa chuyển được video mới "' + video.name + '" sang thư mục cũ: ' + e.message, 'warn'); }
}

async function pickNewFolder() {
  try {
    const h = await window.showDirectoryPicker({ mode: 'readwrite', id: 'vc-newvideos' });
    if (dirHandle && (await dirHandle.isSameEntry(h))) { showBanner('Thư mục video mới không được trùng với thư mục video cũ.'); return; }
    hideBanner();
    newDirHandle = h;
    await idbSet('newdir', h);
    await refreshNewInfo();
  } catch (e) { if (e.name !== 'AbortError') log('Không chọn được thư mục video mới: ' + e.message, 'err'); }
}
async function refreshNewInfo() {
  const el = $('newDirInfo');
  if (!el) return;
  if (!newDirHandle) { el.textContent = 'Chưa chọn thư mục video mới.'; return; }
  let extra = '';
  try {
    if (await newPermOk()) {
      let n = 0;
      for await (const [name, h] of newDirHandle.entries()) if (h.kind === 'file' && VIDEO_RE.test(name)) n++;
      extra = ', đang có ' + n + ' video';
    } else extra = '. Chưa có quyền đọc, bấm Bắt đầu và chọn Cho phép';
  } catch (e) { extra = ''; }
  el.textContent = 'Thư mục video mới: ' + newDirHandle.name + extra + '.';
}

/* ====================== chuyển video lỗi sang thư mục khác ====================== */
const hasRW = async (h) => !!h && (await h.queryPermission({ mode: 'readwrite' })) === 'granted';

const FAIL_DIR_NAME = 'video lỗi';
async function refreshFailInfo() {
  const info = $('failDirInfo');
  if (info) info.textContent = 'Video bị chuyển vào thư mục "' + FAIL_DIR_NAME + '", tool tự tạo bên trong thư mục video khi bắt đầu chạy.';
}
// Tạo (nếu chưa có) thư mục "video lỗi" nằm trong thư mục video đã chọn.
async function ensureFailDir() {
  if (!dirHandle) return false;
  try { await dirHandle.requestPermission({ mode: 'readwrite' }); } catch (e) { /* kiểm tra bên dưới */ }
  if (!(await hasRW(dirHandle))) return false;
  failDirHandle = await dirHandle.getDirectoryHandle(FAIL_DIR_NAME, { create: true });
  return true;
}

// Chuyển (cắt) video sang thư mục đích: chép, kiểm tra dung lượng rồi mới xoá bản gốc.
// Bản khác (extension khác) vừa chuyển rồi thì chỉ xoá bản gốc, không tạo thêm bản "(2)".
async function moveFileTo(video, destDir) {
  const srcDir = video.dir || dirHandle;
  const get = async (n) => { try { return await (await destDir.getFileHandle(n)).getFile(); } catch (e) { return null; } };
  const same = await get(video.name);
  if (same && same.size === video.size) {
    try { await srcDir.removeEntry(video.name); } catch (e) { /* đã bị chuyển đi */ }
    return video.name;
  }
  let name = video.name;
  if (same) {
    const base = stem(name), ext = name.slice(base.length);
    let i = 2;
    while (await get(base + ' (' + i + ')' + ext)) i++;
    name = base + ' (' + i + ')' + ext;
  }
  const file = await video.handle.getFile();
  const out = await (await destDir.getFileHandle(name, { create: true })).createWritable();
  await file.stream().pipeTo(out);
  const copied = await (await destDir.getFileHandle(name)).getFile();
  if (copied.size !== file.size) throw new Error('Bản sao không khớp dung lượng, giữ nguyên file gốc');
  await srcDir.removeEntry(video.name);
  return name;
}

async function moveVideo(video) {
  if (!(await ensureFailDir())) throw new Error('Chưa có quyền ghi thư mục video');
  return moveFileTo(video, failDirHandle);
}

const FAIL_PAGES_TO_MOVE = 3; // video lỗi ở 3 page khác nhau (chưa đăng được page nào) thì chuyển
const failCount = (key) => (Array.isArray(videoFails[key]) ? videoFails[key].length : 0);
function bumpFail(video, pages) {
  let a = videoFails[video.key];
  if (!Array.isArray(a)) a = [];
  for (const p of pages) if (!a.includes(p)) a.push(p);
  videoFails[video.key] = a;
  chrome.storage.local.set({ videoFails });
  return a.length;
}

function clearFail(video) {
  if (videoFails[video.key]) { delete videoFails[video.key]; chrome.storage.local.set({ videoFails }); }
}

async function moveBadVideos(toMove) {
  for (const v of toMove.values()) {
    if (failCount(v.key) < FAIL_PAGES_TO_MOVE) continue;
    try {
      const to = await moveVideo(v);
      delete videoFails[v.key];
      chrome.storage.local.set({ videoFails });
      log('Video "' + v.name + '" lỗi ở ' + FAIL_PAGES_TO_MOVE + ' page, đã chuyển sang thư mục "' + failDirHandle.name + '"' + (to !== v.name ? ' (đổi tên thành ' + to + ')' : ''), 'warn');
    } catch (e) {
      log('Không chuyển được video "' + v.name + '": ' + e.message, 'err');
    }
  }
  await refreshFolderInfo();
}

/* ====================== thống kê ====================== */
// Thống kê hôm nay (tính lại từ 0 giờ đêm) và tổng từ trước đến nay.
function dayStats() {
  const k = todayStr();
  if (!stats.today || stats.today.day !== k) stats.today = { day: k, success: 0, fail: 0, runs: 0, byPage: {} };
  return stats.today;
}
function renderStats() {
  const d = dayStats();
  $('stOk').textContent = d.success;
  $('stOkAll').textContent = stats.success;
  $('stFail').textContent = d.fail;
  $('stFailAll').textContent = stats.fail;
  $('stRuns').textContent = d.runs;
  $('stRunsAll').textContent = stats.runs;
  const names = Object.keys(stats.byPage);
  const tb = $('stTable');
  tb.textContent = '';
  if (!names.length) {
    const tr = tb.insertRow(); const td = tr.insertCell(); td.colSpan = 3; td.className = 'note'; td.textContent = 'Chưa có dữ liệu.';
    return;
  }
  for (const n of names.sort()) {
    const t = stats.byPage[n];
    const dd = d.byPage[n] || { success: 0, fail: 0 };
    const tr = tb.insertRow();
    tr.insertCell().textContent = n;
    const c1 = tr.insertCell(); c1.textContent = dd.success + ' / ' + t.success; if (dd.success) c1.className = 'hot';
    tr.insertCell().textContent = dd.fail + ' / ' + t.fail;
  }
}

function addStat(name, ok) {
  const p = stats.byPage[name] || (stats.byPage[name] = { success: 0, fail: 0 });
  const d = dayStats();
  const dp = d.byPage[name] || (d.byPage[name] = { success: 0, fail: 0 });
  if (ok) { stats.success++; p.success++; d.success++; dp.success++; } else { stats.fail++; p.fail++; d.fail++; dp.fail++; }
}

function renderFailList(items) {
  const ul = $('failList');
  ul.textContent = '';
  if (!items.length) { const li = document.createElement('li'); li.className = 'note'; li.textContent = 'Không có page lỗi.'; ul.append(li); return; }
  for (const it of items) {
    const li = document.createElement('li');
    li.textContent = it.name + (it.video ? ' (video: ' + it.video + ')' : '') + (it.message ? ': ' + it.message : '');
    ul.append(li);
  }
}

function renderFailVideos() {
  const ul = $('failVideos');
  ul.textContent = '';
  if (!failedVideos.length) { const li = document.createElement('li'); li.className = 'note'; li.textContent = 'Chưa có.'; ul.append(li); return; }
  for (const f of failedVideos) {
    const li = document.createElement('li');
    const b = document.createElement('b');
    b.textContent = f.video;
    li.append(b, document.createElement('br'), document.createTextNode('Page: ' + f.page + ' (' + f.time + ')' + (f.message ? ': ' + f.message : '')));
    ul.append(li);
  }
}

function addFailVideo(video, page, message) {
  const d = new Date();
  failedVideos.unshift({ time: pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()), video, page, message: message || '' });
  failedVideos = failedVideos.slice(0, 200);
  saveFailedVideos();
  renderFailVideos();
}

/* ====================== chờ có thể dừng ====================== */
const timer = new Worker('timer-worker.js');
let tseq = 0;
const waiters = {};
timer.onmessage = (e) => { const f = waiters[e.data.id]; if (f) { delete waiters[e.data.id]; f(); } };
const tick = (ms) => new Promise((r) => { const id = ++tseq; waiters[id] = r; timer.postMessage({ id, ms }); });
const chk = () => { if (run.stop) throw new Stop('Đã dừng'); };
async function sleep(ms) { let left = ms; while (left > 0) { chk(); const s = Math.min(500, left); await tick(s); left -= s; } chk(); }

/* ====================== điều khiển tab ====================== */
async function tabCmd(msg) {
  chk();
  let r;
  try { r = await chrome.tabs.sendMessage(run.tabId, msg); }
  catch (e) { throw new Error('Mất kết nối với trang (' + (e.message || e) + ')'); }
  if (!r) throw new Error('Trang không phản hồi');
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

async function waitTabComplete(tabId, timeout = 45000) {
  const t0 = Date.now();
  await sleep(1200);
  for (;;) {
    let tab;
    try { tab = await chrome.tabs.get(tabId); } catch (e) { throw new Error('Tab đã bị đóng'); }
    if (tab.status === 'complete') return tab;
    if (Date.now() - t0 > timeout) throw new Error('Trang tải quá lâu');
    await sleep(500);
  }
}

async function waitContent() {
  for (let i = 0; i < 40; i++) {
    try { await tabCmd({ cmd: 'ping' }); return; } catch (e) { if (e instanceof Stop) throw e; await sleep(750); }
  }
  throw new Error('Không kết nối được với trang fb0t.com (hãy tải lại extension rồi thử lại)');
}

async function closeRunTab() {
  if (run.tabId != null) { try { await chrome.tabs.remove(run.tabId); } catch (e) { /* đã đóng */ } run.tabId = null; }
}

let stolen = false; // đã kéo tab bảng điều khiển lên trước (cần trả lại tab chạy)
async function focusDashboard() {
  stolen = true;
  try {
    const me = await chrome.tabs.getCurrent();
    if (me) {
      await chrome.tabs.update(me.id, { active: true });
      await chrome.windows.update(me.windowId, { focused: true });
    }
  } catch (e) { /* bỏ qua */ }
  await sleep(600);
}

async function backToRunTab() {
  try { if (run.tabId != null) await chrome.tabs.update(run.tabId, { active: true }); } catch (e) { /* tab đã đóng */ }
}

/* ====================== kiểm tra nick ====================== */
async function checkNick() {
  await closeRunTab();
  const tab = await chrome.tabs.create({ url: FB_URL, active: !S.quiet });
  run.tabId = tab.id;
  await waitTabComplete(tab.id);
  await sleep(2500);
  const cur = await chrome.tabs.get(tab.id);
  const url = cur.url || '';
  if (/checkpoint|\/login|login\.php|recover|disabled|suspended/i.test(url)) {
    throw new NickError('Nick lỗi: Facebook chuyển sang trang đăng nhập/checkpoint (' + url.slice(0, 80) + ')');
  }
  const ck = await chrome.cookies.get({ url: FB_URL, name: 'c_user' });
  if (!ck) throw new NickError('Nick đã văng: không còn đăng nhập Facebook');
  let text = '';
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body ? document.body.innerText.slice(0, 4000) : '') });
    text = (r && r.result) || '';
  } catch (e) { /* bỏ qua */ }
  if (/your account has been (suspended|disabled|locked)|we suspended your account|confirm your identity|xác nhận danh tính|tài khoản[^.]{0,40}(bị khóa|bị khoá|bị vô hiệu hóa|bị vô hiệu hoá|bị đình chỉ)|checkpoint/i.test(text)) {
    throw new NickError('Nick dính checkpoint hoặc bị khoá');
  }
}

/* ====================== cắt ảnh từ video ====================== */
function mediaErr(el) {
  const c = el.error && el.error.code;
  if (c === 4) return 'Chrome không giải mã được định dạng video này (thường là H.265/HEVC hoặc codec lạ)';
  if (c === 3) return 'Video bị lỗi khi giải mã';
  if (c === 2) return 'Lỗi khi đọc file video';
  if (c === 1) return 'Việc đọc video bị huỷ';
  return 'Chrome không đọc được video này';
}

function waitEvent(el, ev, ms, stage) {
  return new Promise((res, rej) => {
    const t = setTimeout(() => {
      cleanup();
      rej(new Error('Quá thời gian chờ ở bước "' + stage + '" (readyState ' + el.readyState + ', networkState ' + el.networkState + ')'));
    }, ms);
    const ok = () => { cleanup(); res(); };
    const bad = () => { cleanup(); rej(new Error(mediaErr(el))); };
    function cleanup() { clearTimeout(t); el.removeEventListener(ev, ok); el.removeEventListener('error', bad); }
    el.addEventListener(ev, ok);
    el.addEventListener('error', bad);
  });
}

async function captureFrame(file, ratio, fast) {
  const url = URL.createObjectURL(file);
  const v = document.createElement('video');
  try {
    v.muted = true; v.preload = 'auto'; v.playsInline = true;
    v.style.cssText = 'position:fixed;left:-9999px;top:0;width:2px;height:2px;opacity:0;pointer-events:none';
    document.body.appendChild(v);
    v.src = url;
    v.load();
    if (v.readyState < 1) await waitEvent(v, 'loadedmetadata', fast ? 10000 : 30000, 'đọc thông tin video');
    const dur = isFinite(v.duration) ? v.duration : 6;
    const lo = Math.min(2, Math.max(0, dur - 0.2));
    const hi = Math.min(6, Math.max(lo, dur - 0.2));
    const t = lo + Math.random() * (hi - lo);
    v.currentTime = t;
    await waitEvent(v, 'seeked', fast ? 10000 : 30000, 'nhảy tới giây ' + t.toFixed(1));
    if (v.readyState < 2) await waitEvent(v, 'loadeddata', fast ? 6000 : 15000, 'giải mã khung hình');
    const vw = v.videoWidth, vh = v.videoHeight;
    if (!vw || !vh) throw new Error('Không lấy được kích thước video');
    const [rw, rh] = ratio === '9:16' ? [9, 16] : [1, 1];
    let cw = vw, ch = Math.round((vw * rh) / rw);
    if (ch > vh) { ch = vh; cw = Math.round((vh * rw) / rh); }
    const sx = Math.round((vw - cw) / 2), sy = Math.round((vh - ch) / 2);
    const scale = Math.min(1, 1920 / Math.max(cw, ch));
    const c = document.createElement('canvas');
    c.width = Math.round(cw * scale); c.height = Math.round(ch * scale);
    c.getContext('2d').drawImage(v, sx, sy, cw, ch, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.92));
    if (!blob) throw new Error('Không tạo được ảnh');
    return { blob, name: 'thumb_' + (Math.round(t * 10) / 10) + 's.jpg', sec: t };
  } finally {
    try { v.removeAttribute('src'); v.load(); } catch (e) { /* bỏ qua */ }
    v.remove();
    URL.revokeObjectURL(url);
  }
}

// Lấy ảnh cho một ô: cố định, thumb cùng tên video (nếu có), hoặc tự cắt từ video.
async function getImage(label, mode, ratio, fixedImg, video, file, tag) {
  if (mode === 'fixed') return fixedImg;
  if (mode === 'thumb') {
    const th = await findThumb(video.name);
    if (th) { log(label + ': dùng ảnh thumb cùng tên video (' + th.name + ')', 'ok'); return { blob: th, name: th.name }; }
    log(label + ': không có ảnh thumb tên "' + stem(video.name) + '" trong thư mục, chuyển sang tự cắt từ video', 'warn');
  }
  setStatus(tag + 'Cắt ' + label.toLowerCase() + ' từ video...', 'busy');
  let c;
  try {
    c = await captureFrame(file, ratio, S.quiet);
  } catch (e) {
    log(label + ': cắt ảnh lỗi (' + e.message + '), kéo tab lên trước rồi thử lại 1 lần', 'warn');
    await focusDashboard();
    c = await captureFrame(file, ratio, false);
  }
  log(label + ': khung hình giây ' + c.sec.toFixed(1) + ', tỉ lệ ' + ratio);
  return c;
}

/* ====================== gửi file sang trang ====================== */
const blobToB64 = (b) => new Promise((res, rej) => {
  const fr = new FileReader();
  fr.onload = () => res(String(fr.result).split(',')[1] || '');
  fr.onerror = () => rej(fr.error);
  fr.readAsDataURL(b);
});

async function sendFile(slot, blob, name) {
  const CH = 3 * 1024 * 1024;
  const total = Math.max(1, Math.ceil(blob.size / CH));
  const id = slot + '-' + Date.now();
  let last;
  for (let i = 0; i < total; i++) {
    chk();
    const b64 = await blobToB64(blob.slice(i * CH, (i + 1) * CH));
    last = await tabCmd({ cmd: 'fileChunk', id, index: i, total, b64, name, mime: blob.type || 'application/octet-stream', slot });
  }
  return last;
}

/* ====================== chọn video ====================== */
// Video "mới" = video tool mới thấy sau mốc oldBefore. Mọi page phải đăng hết đám video mới (mới nhất trước) thì mốc mới được
// đẩy lên, lúc đó chúng thành video "cũ". Hết video mới thì chọn ngẫu nhiên trong đám video cũ mà page đó chưa đăng.
// cands đã xếp mới nhất trước.
let oldBefore = 0;
const deadPages = new Set(); // page đã lỗi đủ số lần ở lượt chạy này: không chờ nó đăng video mới nữa
const freshPending = (page, vids) => vids.some((v) => isFresh(v) && !(history[v.key] || []).includes(norm(page)));
const isFresh = (v) => (S.useNewDir ? !!v.isNew : (firstSeen[v.key] || 0) > oldBefore);
function chooseVideo(cands) {
  if (S.useNewDir) {
    // có thư mục video mới: video mới nhất đăng trước, hết video mới mới sang video cũ (ngẫu nhiên)
    const fr = cands.filter(isFresh);
    if (fr.length) return fr[0]; // thư mục mới: video bỏ vào gần nhất đăng trước (danh sách đã xếp mới nhất trước)
    return cands.length ? cands[Math.floor(Math.random() * cands.length)] : null; // thư mục cũ: ngẫu nhiên
  }
  const fresh = cands.find(isFresh);
  if (fresh) return fresh;
  return cands.length ? cands[Math.floor(Math.random() * cands.length)] : null;
}
// Đám video mới đã được mọi page đăng xong thì chuyển hết sang "cũ".
async function settleNew() {
  if (S.useNewDir) return; // có thư mục video mới thì không dùng cách chia mới/cũ theo thời gian
  let vids;
  try { vids = await listVideos(); } catch (e) { return; }
  const pages = lines(S.pagesText);
  if (!pages.length || !vids.length) return;
  const pending = pages.some((p) => !deadPages.has(norm(p)) && freshPending(p, vids));
  if (pending) return;
  const top = Math.max(...vids.map((v) => firstSeen[v.key] || 0));
  if (top > oldBefore) { oldBefore = top; await chrome.storage.local.set({ oldBefore }); log('Đã đăng xong đám video mới cho mọi page, từ giờ video đó tính là video cũ', 'ok'); }
}

// Video đã lỗi ở page nào thì 12 giờ sau mới thử lại cặp đó, để page chuyển sang video khác thay vì lặp 2 video lỗi.
let pageBad = {}; // normPage -> { videoKey: thời điểm lỗi }
const BAD_MS = 12 * 3600 * 1000;
function isBad(p, key) { const t = pageBad[p] && pageBad[p][key]; return !!t && Date.now() - t < BAD_MS; }
function markBad(typed, key) {
  const p = norm(typed);
  (pageBad[p] || (pageBad[p] = {}))[key] = Date.now();
  for (const q of Object.keys(pageBad)) for (const k of Object.keys(pageBad[q])) if (Date.now() - pageBad[q][k] >= BAD_MS) delete pageBad[q][k];
  chrome.storage.local.set({ pageBad });
}
function pickVideo(videos, typedPages, excludeKeys, forceKey) {
  if (forceKey) return videos.find((v) => v.key === forceKey) || null;
  const ps = typedPages.map(norm);
  return chooseVideo(videos.filter((v) => !excludeKeys.has(v.key) && !ps.some((p) => (history[v.key] || []).includes(p) || isBad(p, v.key))));
}

function markPosted(key, typed) {
  const p = norm(typed);
  const arr = history[key] || (history[key] = []);
  if (!arr.includes(p)) arr.push(p);
}

/* ====================== file kết quả (ket-qua-dang.txt) ====================== */
// File nằm trong thư mục video. Mỗi dòng: giờ | page | tên video | dung lượng | THÀNH CÔNG hoặc LỖI
// Khi bắt đầu chạy, tool đọc file này để biết page nào đã đăng video nào. Xoá dòng nào thì tool cho đăng lại cặp đó.
let RESULT_FILE = 'ket-qua-dang.txt';
// Nhiều bản extension dùng chung một thư mục video: mỗi bản có file kết quả riêng, đặt tên theo "tên extension"
// bạn nhập, mặc định là 6 ký tự đầu của mã extension (mã này cố định theo thư mục cài đặt nên tự nhận ra file của mình).
function instTag() {
  const n = (S.instName || '').normalize('NFC').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);
  return n || chrome.runtime.id.slice(0, 6);
}
function updateResultFileName() {
  RESULT_FILE = 'ket-qua-dang-' + instTag() + '.txt';
  const label = (S.instName || '').trim();
  document.title = label ? 'Thanh Can code - ' + label : 'Thanh Can code';
  const h1 = document.querySelector('.bar h1');
  if (h1) h1.textContent = document.title;
  const el = $('resultFileInfo');
  if (el) el.textContent = 'File lịch sử của extension này: ' + RESULT_FILE + ' (nằm trong thư mục video, các extension khác không đọc file này).';
}
let pendingLines = [];
const stamp = () => { const d = new Date(), z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ':' + z(d.getSeconds()); };
const clean = (x) => String(x || '').replace(/[\r\n|]+/g, ' ').trim();
// status: 'ok' (THÀNH CÔNG) | 'fail' (LỖI) | 'unk' (CHƯA RÕ: bấm Post rồi nhưng không đọc được kết quả; coi như đã đăng để không đăng trùng)
function queueResult(typed, video, status, actual) {
  if (!video) return;
  const st = status === 'ok' ? 'THÀNH CÔNG' : status === 'unk' ? 'CHƯA RÕ' : 'LỖI';
  pendingLines.push([stamp(), clean(typed), clean(video.name), video.size, st, clean(actual || typed)].join(' | '));
}
async function readResultText() {
  try { return await (await (await dirHandle.getFileHandle(RESULT_FILE)).getFile()).text(); } catch (e) { return null; }
}
async function writeResultText(text) {
  const fh = await dirHandle.getFileHandle(RESULT_FILE, { create: true });
  const w = await fh.createWritable();
  await w.write(text); await w.close();
}
async function flushResultFile() {
  if (!pendingLines.length) return;
  const lines = pendingLines; pendingLines = [];
  try {
    if (!(await hasRW(dirHandle))) throw new Error('chưa có quyền ghi thư mục video');
    const old = (await readResultText()) || '';
    await writeResultText(old + (old && !old.endsWith('\n') ? '\n' : '') + lines.join('\n') + '\n');
    chrome.storage.local.set({ pendingLines: [] });
  } catch (e) {
    // giữ lại để lần sau ghi bù, không để mất lịch sử
    pendingLines = lines.concat(pendingLines);
    chrome.storage.local.set({ pendingLines });
    log('Chưa ghi được ' + RESULT_FILE + ' (' + e.message + '), tool giữ lại và ghi bù lần sau', 'warn');
  }
}
// Đọc file khi bắt đầu chạy: file là nguồn đúng nhất. Chưa có file thì tạo từ bộ nhớ cũ.
async function loadResultFile() {
  if (!dirHandle) return;
  try {
    await dirHandle.requestPermission({ mode: 'readwrite' });
  } catch (e) { /* bỏ qua */ }
  if (!(await hasRW(dirHandle))) {
    log('Chưa có quyền ghi thư mục video nên không lưu được ' + RESULT_FILE + ' (vẫn nhớ trong extension).', 'warn');
    return;
  }
  let text = await readResultText();
  if (text === null) {
    const seed = [];
    for (const k of Object.keys(history)) {
      const i = k.lastIndexOf('|');
      for (const pg of history[k]) seed.push(['(cũ)', pg, k.slice(0, i), k.slice(i + 1), 'THÀNH CÔNG'].join(' | '));
    }
    // Đổi tên extension thì file mới trống: chép luôn số liệu theo ngày để thống kê hôm nay và giới hạn bài mỗi ngày không bị về 0
    for (const day of Object.keys(dailyLog).sort().slice(-45)) {
      for (const x of Object.values(dailyLog[day] || {})) {
        for (let i = 0; i < x.n; i++) seed.push([day + ' 00:00:00', clean(x.name), '(chuyển từ tên cũ)', 0, 'THÀNH CÔNG', clean(x.name)].join(' | '));
      }
    }
    const td = stats.today;
    if (td && td.day === todayStr()) {
      for (const [nm, p] of Object.entries(td.byPage || {})) {
        for (let i = 0; i < (p.fail || 0); i++) seed.push([td.day + ' 00:00:00', clean(nm), '(chuyển từ tên cũ)', 0, 'LỖI', clean(nm)].join(' | '));
      }
    }
    if (seed.length) await writeResultText(seed.join('\n') + '\n');
    log('Đã tạo ' + RESULT_FILE + ' trong thư mục video' + (seed.length ? ' (chép ' + seed.length + ' dòng từ bộ nhớ cũ)' : ''), 'ok');
    text = (await readResultText()) || '';
  }
  if (pendingLines.length) { await flushResultFile(); text = (await readResultText()) || ''; }
  const h = {};
  const dl = {};
  let n = 0;
  for (const line of text.split(/\r?\n/)) {
    const c = line.split(' | ').map((x) => x.trim());
    if (c.length < 5) continue;
    const st = c[4].toUpperCase();
    if (st !== 'THÀNH CÔNG' && st !== 'CHƯA RÕ') continue; // CHƯA RÕ cũng tính là đã đăng để không đăng trùng
    const key = c[2] + '|' + c[3];
    const pg = norm(c[1]);
    (h[key] || (h[key] = [])).includes(pg) || h[key].push(pg);
    n++;
    const day = /^\d{4}-\d{2}-\d{2}/.test(c[0]) ? c[0].slice(0, 10) : '';
    if (day && st === 'THÀNH CÔNG') {
      const d = dl[day] || (dl[day] = {});
      (d[pg] || (d[pg] = { name: c[5] || c[1], n: 0 })).n++;
    }
  }
  if (!stats.success && !stats.fail && !stats.runs) {
    // máy/Chrome mới chưa có thống kê: dựng lại từ file lịch sử của extension này
    const bp = {};
    let ok = 0, bad = 0;
    for (const line of text.split(/\r?\n/)) {
      const c = line.split(' | ').map((x) => x.trim());
      if (c.length < 5) continue;
      const st = c[4].toUpperCase();
      if (st !== 'THÀNH CÔNG' && st !== 'LỖI') continue;
      const nm = c[5] || c[1];
      const p = bp[nm] || (bp[nm] = { success: 0, fail: 0 });
      if (st === 'THÀNH CÔNG') { ok++; p.success++; } else { bad++; p.fail++; }
    }
    if (ok || bad) {
      stats.success = ok; stats.fail = bad; stats.byPage = bp;
      await saveStats(); renderStats();
      log('Đã dựng lại thống kê từ ' + RESULT_FILE + ': ' + ok + ' thành công, ' + bad + ' lỗi', 'ok');
    }
  }
  {
    const today = todayStr();
    const td = { day: today, success: 0, fail: 0, runs: (stats.today && stats.today.day === today ? stats.today.runs : 0), byPage: {} };
    let any = false;
    for (const line of text.split(/\r?\n/)) {
      const c = line.split(' | ').map((x) => x.trim());
      if (c.length < 5 || c[0].slice(0, 10) !== today) continue;
      const st = c[4].toUpperCase();
      if (st !== 'THÀNH CÔNG' && st !== 'LỖI') continue;
      const nm = c[5] || c[1];
      const p = td.byPage[nm] || (td.byPage[nm] = { success: 0, fail: 0 });
      any = true;
      if (st === 'THÀNH CÔNG') { td.success++; p.success++; } else { td.fail++; p.fail++; }
    }
    if (any) { stats.today = td; await saveStats(); renderStats(); }
  }
  history = h;
  dailyLog = dl; // file là nguồn đúng nhất cho thống kê hàng ngày
  await chrome.storage.local.set({ history, dailyLog });
  renderDaily();
  log('Đã đọc ' + RESULT_FILE + ': ' + n + ' lượt đã đăng trước đó', 'ok');
}

// Bấm Post xong mà bị ngắt (tắt máy, mất mạng) trước khi ghi nhận: coi như đã đăng, không đăng lại.
async function resolveInflight() {
  const r = await chrome.storage.local.get('inflight');
  const f = r.inflight;
  if (!f || !f.video) return;
  for (const p of f.pages || []) {
    markPosted(f.video.key, p);
    pendingLines.push([f.at || stamp(), clean(p), clean(f.video.name), f.video.size, 'CHƯA RÕ', clean(p)].join(' | '));
  }
  await chrome.storage.local.remove('inflight');
  await saveHistory();
  log('Lần chạy trước bị ngắt ngay lúc đăng video "' + f.video.name + '" (' + (f.pages || []).join(', ') + '). Tool coi như đã đăng, không đăng lại. Muốn đăng lại thì xoá dòng CHƯA RÕ trong ' + RESULT_FILE + '.', 'warn');
}

/* ====================== giới hạn và thống kê theo ngày (tính lại từ 0 giờ đêm) ====================== */
let dailyLog = {}; // "YYYY-MM-DD" -> { tên page chuẩn hoá: { name, n } } chỉ tính lượt thành công
const todayStr = () => dayKey(new Date());
const dayCount = (typed) => (((dailyLog[todayStr()] || {})[norm(typed)]) || { n: 0 }).n;
const limitReached = (typed) => S.dailyLimit > 0 && dayCount(typed) >= S.dailyLimit;
function bumpDaily(typed, actual) {
  const day = todayStr();
  const d = dailyLog[day] || (dailyLog[day] = {});
  const k = norm(typed);
  (d[k] || (d[k] = { name: actual || typed, n: 0 })).n++;
  const days = Object.keys(dailyLog).sort();
  while (days.length > 45) delete dailyLog[days.shift()];
  chrome.storage.local.set({ dailyLog });
  renderDaily();
}
// Chỉ hiện thống kê trong ngày hôm nay: đếm từ 0 giờ sáng đến lúc bấm, chỉ tính lượt thành công.
function renderDaily(until) {
  const box = $('dailyBox');
  if (!box) return;
  box.textContent = '';
  const now = new Date();
  const z = (n) => String(n).padStart(2, '0');
  const h = document.createElement('h3');
  h.textContent = 'Hôm nay ' + z(now.getDate()) + '/' + z(now.getMonth() + 1) + '/' + now.getFullYear() + ', từ 00:00 đến ' + (until ? z(until.getHours()) + ':' + z(until.getMinutes()) : 'giờ hiện tại');
  box.append(h);
  const items = Object.values(dailyLog[todayStr()] || {}).filter((x) => x.n > 0).sort((a, b) => a.name.localeCompare(b.name, 'vi'));
  if (!items.length) { const p = document.createElement('p'); p.className = 'note'; p.textContent = 'Hôm nay chưa đăng được video nào.'; box.append(p); return; }
  const ul = document.createElement('ul');
  ul.className = 'daylist';
  let total = 0;
  for (const x of items) {
    const li = document.createElement('li');
    li.textContent = x.name + ' đăng ' + x.n + ' video thành công';
    ul.append(li);
    total += x.n;
  }
  const t = document.createElement('li');
  t.className = 'total';
  t.textContent = 'Tổng: ' + total + ' video';
  ul.append(t);
  box.append(ul);
}

// Bấm nút Thống kê: đếm lại từ file kết quả, từ 0 giờ sáng đến lúc bấm.
async function refreshDaily() {
  const until = new Date();
  const today = dayKey(until);
  if (dirHandle) {
    try {
      const text = await readResultText();
      if (text !== null) {
        const d = {};
        for (const line of text.split(/\r?\n/)) {
          const c = line.split(' | ').map((x) => x.trim());
          if (c.length < 5 || c[4].toUpperCase() !== 'THÀNH CÔNG' || c[0].slice(0, 10) !== today) continue;
          const pg = norm(c[1]);
          (d[pg] || (d[pg] = { name: c[5] || c[1], n: 0 })).n++;
        }
        dailyLog[today] = d;
        chrome.storage.local.set({ dailyLog });
      }
    } catch (e) { log('Không đọc được file kết quả để thống kê, dùng số đang nhớ: ' + e.message, 'warn'); }
  }
  renderDaily(until);
}

/* ====================== mạng và hết video ====================== */
async function waitOnline() {
  if (navigator.onLine) return;
  log('Mất mạng, tool chờ có mạng lại rồi chạy tiếp...', 'warn');
  while (!navigator.onLine) { setStatus('Mất mạng, đang chờ có mạng lại...', 'busy'); await sleep(5000); }
  log('Đã có mạng lại, chạy tiếp', 'ok');
  await sleep(3000);
}

// Hết video = mọi page trong danh sách đều đã đăng mọi video đang có trong thư mục. Mỗi lần gọi đều quét lại thư mục.
let outAlerted = false;
async function checkOut() {
  await settleNew();
  const pages = lines(S.pagesText);
  let vids;
  try { vids = await listVideos(); } catch (e) { return false; }
  const left = pages.some((p) => vids.some((v) => !(history[v.key] || []).includes(norm(p))));
  if (left) { outAlerted = false; return false; }
  if (!outAlerted) {
    outAlerted = true;
    const msg = 'Mọi page đã đăng hết video trong thư mục. Bỏ thêm video vào thư mục, tool tự quét lại và chạy tiếp.';
    log('HẾT VIDEO: ' + msg, 'err');
    showBanner('Hết video. ' + msg);
    notify('Hết video', msg, 'out');
  }
  return true;
}

/* ====================== một lần đăng ====================== */
async function attempt(typedNames, excludeKeys, isRetry, forceKey) {
  const tag = isRetry ? '[Chạy lại] ' : '';
  run.curVideo = null;

  let reuseTab = false;
  if (isRetry && run.tabId != null) {
    try { await chrome.tabs.get(run.tabId); reuseTab = true; } catch (e) { run.tabId = null; }
  }
  if (reuseTab) {
    log('Chạy lại: dùng lại tab đang mở, không kiểm tra nick lần nữa (vừa kiểm tra xong)');
  } else if (S.checkNick) {
    setStatus(tag + 'Kiểm tra nick Facebook...', 'busy');
    log(tag + 'Kiểm tra nick trên facebook.com');
    await checkNick();
    log('Nick bình thường', 'ok');
  } else {
    await closeRunTab();
    const nt = await chrome.tabs.create({ url: 'about:blank', active: !S.quiet });
    run.tabId = nt.id;
  }

  setStatus(tag + 'Mở trang đăng Video Carousel...', 'busy');
  await chrome.tabs.update(run.tabId, { url: TOOL_URL, active: !S.quiet });
  await waitTabComplete(run.tabId);
  await waitContent();

  setStatus(tag + 'Đợi danh sách page hiện ra...', 'busy');
  await sleep(4500);
  const t0 = Date.now();
  for (;;) {
    const list = await tabCmd({ cmd: 'listPages' });
    if (list.length) break;
    if (Date.now() - t0 > 60000) throw new Error('Không thấy danh sách page sau 60 giây (nick có vấn đề hoặc trang chưa tải được)');
    await sleep(1000);
  }

  setStatus(tag + 'Chọn page...', 'busy');
  const tk = await tabCmd({ cmd: 'tickPages', names: typedNames });
  const results = tk.missing.map((m) => ({ name: m, typed: m, status: 'error', message: 'Không tìm thấy page này trong danh sách', notFound: true }));
  if (!tk.ticked.length) return { video: null, results };
  log('Đã chọn page: ' + tk.ticked.map((t) => t.actual).join(', '));
  const actualNames = tk.ticked.map((t) => t.actual);
  const typedTicked = tk.ticked.map((t) => t.typed);

  setStatus(tag + 'Chọn video...', 'busy');
  const videos = await listVideos();
  let video = pickVideo(videos, typedTicked, excludeKeys, forceKey);
  // video mới trong thư mục dùng chung: kiểm tra lại số lần đã đăng rồi giữ chỗ trước khi đăng
  while (video && video.isNew && !forceKey) {
    const t = tallyNew(await sharedLines(), video.key);
    if (t.done + t.claims < S.newMax) break;
    excludeKeys = new Set([...excludeKeys, video.key]);
    video = pickVideo(videos, typedTicked, excludeKeys, forceKey);
  }
  if (!video) throw new Error('Hết video mới: mọi video trong thư mục đã đăng cho page này');
  if (video.isNew) await claimNew(video);
  let file;
  try { file = await video.handle.getFile(); } catch (e) { throw new Error('Video "' + video.name + '" không còn trong thư mục (bản extension khác vừa chuyển đi?), thử lại video khác'); }
  const title = stem(video.name);
  run.curVideo = video.name;
  log('Video: ' + video.name);

  let cover, card2;
  if (!S.quiet) await focusDashboard(); // chạy ngầm thì thử cắt ảnh ở nền trước, không được mới kéo tab lên
  try {
    cover = await getImage('Ảnh bìa', S.coverMode, S.coverRatio, fixed.cover, video, file, tag);
    card2 = await getImage('Ảnh Card 2', S.card2Mode, S.card2Ratio, fixed.card2, video, file, tag);
  } finally {
    if (stolen) { stolen = false; await backToRunTab(); }
  }

  setStatus(tag + 'Upload video...', 'busy');
  await sendFile('video', file, video.name);
  await sleep(1500);
  setStatus(tag + 'Upload ảnh bìa...', 'busy');
  await sendFile('cover', cover.blob, cover.name);
  await sleep(800);
  setStatus(tag + 'Upload ảnh Card 2...', 'busy');
  await sendFile('card2', card2.blob, card2.name);
  await sleep(800);

  setStatus(tag + 'Điền mô tả, tiêu đề, link...', 'busy');
  let link = null;
  const links = lines(S.linksText);
  if (links.length) { link = links[state.linkIdx % links.length]; state.linkIdx = (state.linkIdx + 1) % links.length; await saveState(); }
  await tabCmd({ cmd: 'fillText', description: title, title1: S.title1.trim(), title2: S.title2.trim(), link });
  const bt = await tabCmd({ cmd: 'ensureOpenLink' });
  log(bt.changed ? 'Button Type đã đổi từ "' + bt.before + '" sang Open Link' : 'Button Type đã là Open Link');

  setStatus(tag + 'Đợi nút Post sẵn sàng...', 'busy');
  const p0 = Date.now();
  for (;;) {
    const ps = await tabCmd({ cmd: 'postState' });
    if (ps.found && !ps.disabled) break;
    if (Date.now() - p0 > 150000) throw new Error('Nút Post vẫn chưa bấm được sau 150 giây (thiếu video, ảnh hoặc page?)');
    await sleep(1000);
  }

  setStatus(tag + 'Bấm Post Video Carousel...', 'busy');
  // ghi trước khi bấm Post: nếu bị ngắt giữa chừng thì lần sau biết video này có thể đã được đăng
  await chrome.storage.local.set({ inflight: { pages: typedTicked, video: { key: video.key, name: video.name, size: video.size }, at: stamp() } });
  await tabCmd({ cmd: 'clickPost' });
  log('Đã bấm Post, đợi kết quả...');

  // Dòng nào chưa có kết quả thì tính là "đang chờ", không bị đọc nhầm, nên đọc sớm và đọc dày là an toàn.
  const limit = (150 + 25 * actualNames.length) * 1000;
  const r0 = Date.now();
  await sleep(5000 + Math.floor(Math.random() * 2000)); // đợi 5-7 giây rồi mới đọc Results
  let rows = [];
  let warned = false;
  for (;;) {
    const rr = await tabCmd({ cmd: 'readResults', names: actualNames });
    rows = rr.rows;
    const left = rows.filter((x) => x.status === 'pending').length;
    setStatus(tag + 'Đợi kết quả (' + (rows.length - left) + '/' + rows.length + ' page)...', 'busy');
    if (!rr.found && !warned && Date.now() - r0 > 40000) { warned = true; log('Chưa thấy mục Results trên trang sau 40 giây, vẫn đợi thêm', 'warn'); }
    if (!left) break;
    if (Date.now() - r0 > limit) break;
    await sleep(2000);
  }
  log('Đã đọc xong kết quả sau ' + Math.round((Date.now() - r0) / 1000) + ' giây kể từ lúc bấm Post');
  for (const t of tk.ticked) {
    const row = rows.find((x) => x.name === t.actual) || { status: 'pending' };
    if (row.status === 'success') results.push({ name: t.actual, typed: t.typed, video: video.name, status: 'success' });
    else results.push({ name: t.actual, typed: t.typed, video: video.name, status: 'error', unread: row.status === 'pending', message: row.status === 'pending' ? 'Không thấy kết quả sau khi chờ' : (row.message || 'Lỗi (tool không ghi rõ)') });
  }
  run.curVideo = null;
  return { video, results };
}

/* ====================== một vòng (có chạy lại 1 lần) ====================== */
async function runCycle(targetsArg) {
  await refreshFolderThrottled();
  const pages = lines(S.pagesText);
  let targets;
  let okTotal = 0;
  let forceKey;
  if (targetsArg) targets = targetsArg;
  else if (S.pageMode === 'all') {
    const eligible = pages.filter((p) => !limitReached(p));
    if (!eligible.length) throw new Error('Hết lượt trong ngày: mọi page đã đủ ' + S.dailyLimit + ' bài hôm nay');
    const vids = await listVideos();
    const v = chooseVideo(vids.filter((x) => eligible.some((p) => !(history[x.key] || []).includes(norm(p)) && !isBad(norm(p), x.key))));
    if (!v) throw new Error('Hết video mới: mọi video trong thư mục đã đăng cho các page này');
    targets = eligible.filter((p) => !(history[v.key] || []).includes(norm(p)));
    forceKey = v.key;
    if (S.useNewDir && v.isNew) {
      // video mới chỉ đăng thêm đúng số lần còn thiếu (tính chung mọi extension), không đăng cho tất cả page một lượt
      const t = tallyNew(await sharedLines(), v.key);
      const remain = Math.max(1, S.newMax - t.done - t.claims);
      if (targets.length > remain) { log('Video mới "' + v.name + '": chỉ còn thiếu ' + remain + ' lần nên chỉ đăng ' + remain + ' page', 'warn'); targets = targets.slice(0, remain); }
    }
  }
  else {
    const i = state.pageIdx % pages.length;
    targets = [pages[i]];
    state.pageIdx = (i + 1) % pages.length;
    await saveState();
  }
  stats.runs++; dayStats().runs++;
  renderStats();
  log('Bắt đầu vòng mới, page: ' + targets.join(', '));

  const first = await attempt(targets, new Set(), false, forceKey);
  const finalFailed = [];
  const toMove = new Map();
  const record = (res, video) => {
    let okN = 0, hardFail = 0;
    for (const r of res) {
      if (r.status === 'success') {
        okN++; okTotal++;
        addStat(r.name, true);
        if (video) { markPosted(video.key, r.typed); queueResult(r.typed, video, 'ok', r.name); bumpDaily(r.typed, r.name); }
        log('Thành công: ' + r.name, 'ok');
      } else {
        addStat(r.name, false);
        if (!r.notFound && !r.unread) queueResult(r.typed, video, 'fail', r.name);
        if (r.unread && video) { markPosted(video.key, r.typed); queueResult(r.typed, video, 'unk', r.name); log('Chưa rõ kết quả page "' + r.name + '": coi như đã đăng để không đăng trùng (xoá dòng CHƯA RÕ trong ' + RESULT_FILE + ' nếu muốn đăng lại)', 'warn'); }
        if (!r.notFound && !r.unread) { hardFail++; if (video) markBad(r.typed, video.key); }
        const vn = r.video || (video && video.name) || '';
        log('Lỗi page "' + r.name + '"' + (vn ? ' (video ' + vn + ')' : '') + ': ' + r.message, 'err');
        if (vn && !r.notFound) addFailVideo(vn, r.name, r.message);
      }
    }
    if (video) {
      if (okN > 0) clearFail(video); // đăng được ít nhất một page: video tốt
      else if (hardFail > 0) {
        const fp = res.filter((r) => r.status !== 'success' && !r.notFound && !r.unread).map((r) => norm(r.name));
        const n = bumpFail(video, fp);
        log('Video "' + video.name + '" đã lỗi ở ' + n + '/' + FAIL_PAGES_TO_MOVE + ' page', 'warn');
        if (n >= FAIL_PAGES_TO_MOVE) toMove.set(video.key, video);
      }
    }
  };
  record(first.results, first.video);
  await finishNew(first.video, first.results);
  await saveStats(); await saveHistory(); await chrome.storage.local.remove('inflight');
  renderStats();

  const retryable = first.results.filter((r) => r.status === 'error' && !r.notFound);
  finalFailed.push(...first.results.filter((r) => r.status === 'error' && r.notFound));
  if (retryable.length) {
    log('Chạy lại 1 lần cho ' + retryable.length + ' page lỗi, đổi sang video khác', 'warn');
    try {
      const second = await attempt(retryable.map((r) => r.typed), new Set([first.video.key]), true);
      record(second.results, second.video);
      await finishNew(second.video, second.results);
      finalFailed.push(...second.results.filter((r) => r.status === 'error'));
    } catch (e) {
      if (e instanceof Stop || e instanceof NickError) throw e;
      log('Không chạy lại được: ' + e.message, 'err');
      if (run.curVideo) addFailVideo(run.curVideo, retryable.map((r) => r.name).join(', '), e.message);
      finalFailed.push(...retryable);
    }
    await saveStats(); await saveHistory(); await chrome.storage.local.remove('inflight');
    renderStats();
  }
  if (S.moveFailed && toMove.size) await moveBadVideos(toMove);
  return { failed: finalFailed, okTotal };
}

async function runCycleSafe(targets) {
  try {
    await waitOnline();
    const r = await runCycle(targets);
    refreshFolderInfo();
    renderFailList(r.failed);
    if (r.failed.length) {
      const names = r.failed.map((f) => f.name).join(', ');
      setStatus('Xong vòng. Page lỗi: ' + names, 'err');
    } else {
      setStatus('Xong vòng. Tất cả page thành công.', '');
      await closeRunTab();
    }
    return { ok: r.okTotal, noVideo: false };
  } catch (e) {
    await releaseClaim();
    if (e instanceof Stop) throw e;
    if (e instanceof NickError) { showBanner(e.message); notify('Nick lỗi, đã dừng', e.message); log(e.message, 'err'); throw e; }
    log('Lỗi: ' + e.message, 'err');
    if (run.curVideo) addFailVideo(run.curVideo, '(cả vòng)', e.message);
    setStatus('Lỗi: ' + e.message, 'err');
    return { ok: 0, noVideo: /^Hết video mới/.test(e.message), limited: /^Hết lượt/.test(e.message) };
  }
}

// Xoay vòng page: mỗi page được thử tối đa "maxFail" vòng liên tiếp. Đăng được thì thôi page đó,
// lỗi đủ số lần thì bỏ qua sang page kế tiếp (đếm lại từ đầu). untilOk = dừng ngay khi có 1 lần đăng thành công.
async function rotateRun(untilOk) {
  const pages = lines(S.pagesText);
  const n = pages.length;
  const maxFail = Math.max(1, +S.maxFail || 4);
  let limitedN = 0;
  for (let t = 0; t < n; t++) {
    const i = state.pageIdx % n;
    const page = pages[i];
    let ok = false;
    if (!inActive()) { log('Hết giờ hoạt động, dừng lượt này, chờ đến ' + S.activeFrom, 'warn'); return { ok: false, limitedAll: false }; }
    if (limitReached(page)) {
      limitedN++;
      log('Page "' + page + '" đã đủ ' + S.dailyLimit + ' bài hôm nay, bỏ qua', 'warn');
    } else {
      await settleNew(); // đám video mới đã đăng đủ mọi page thì chuyển thành video cũ
      await refreshFolderThrottled();
      const vids = await listVideos(); // quét lại thư mục mỗi lần, có video mới thêm vào là thấy ngay
      const othersFresh = !S.useNewDir && pages.some((p) => norm(p) !== norm(page) && !deadPages.has(norm(p)) && freshPending(p, vids));
      if (!freshPending(page, vids) && othersFresh) {
        log('Page "' + page + '" đã đăng xong video mới, chờ các page khác đăng hết video mới rồi mới sang video cũ', 'warn');
      } else if (!vids.some((v) => !(history[v.key] || []).includes(norm(page)))) {
        log('Page "' + page + '" đã đăng hết video hiện có, chuyển sang page khác', 'warn');
      } else {
        for (let f = 0; f < maxFail; f++) {
          log('Xoay vòng: page "' + page + '", lượt ' + (f + 1) + '/' + maxFail);
          const r = await runCycleSafe([page]);
          if (r.ok > 0) { ok = true; break; }
          if (!navigator.onLine) { f--; await waitOnline(); continue; } // lỗi do mất mạng thì không tính lượt
          if (r.noVideo) { log('Page "' + page + '" hết video mới để đăng, bỏ qua', 'warn'); break; }
          if (f + 1 < maxFail) await sleep(3000);
          else { deadPages.add(norm(page)); log('Page "' + page + '" lỗi ' + maxFail + ' lần, chuyển sang page khác', 'warn'); }
        }
      }
    }
    state.pageIdx = (i + 1) % n; await saveState();
    if (ok && untilOk) return { ok: true, limitedAll: false };
    if (t < n - 1) await sleep(3000);
  }
  return { ok: false, limitedAll: limitedN === n };
}

/* ====================== giờ hoạt động ====================== */
const hmMin = (t) => { const m = /^(\d{1,2}):(\d{2})$/.exec(t || ''); return m ? +m[1] * 60 + +m[2] : null; };
function inActive(d = new Date()) {
  if (!S.useActive || S.runMode !== 'interval') return true; // giờ hoạt động chỉ dùng cho chế độ chạy cách nhau
  const a = hmMin(S.activeFrom), b = hmMin(S.activeTo);
  if (a === null || b === null || a === b) return true;
  const m = d.getHours() * 60 + d.getMinutes();
  return a < b ? (m >= a && m < b) : (m >= a || m < b); // khung qua đêm, ví dụ 22:00 đến 06:00
}
async function waitActive() {
  if (inActive()) return;
  log('Ngoài giờ hoạt động (' + S.activeFrom + ' đến ' + S.activeTo + '), tool chờ đến ' + S.activeFrom, 'warn');
  while (!inActive()) { setStatus('Ngoài giờ hoạt động, đang chờ mốc ' + S.activeFrom, ''); await sleep(10000); }
  log('Đến giờ hoạt động, chạy tiếp', 'ok');
}

/* ====================== hẹn giờ ====================== */
function parseTimes(text) {
  const ok = [], bad = [];
  for (const l of lines(text)) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(l);
    if (m && +m[1] < 24 && +m[2] < 60) ok.push(pad(+m[1]) + ':' + m[2]); else bad.push(l);
  }
  return { ok: [...new Set(ok)].sort(), bad };
}
const toMin = (t) => +t.slice(0, 2) * 60 + +t.slice(3);
const dayKey = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());

async function runSlot(label) {
  deadPages.clear();
  if (!inActive()) { await chrome.storage.local.remove('slotRun'); return; }
  if (await checkOut()) { setStatus('Hết video, chờ bạn bỏ thêm video vào thư mục. Mốc ' + label, 'err'); return; }
  await chrome.storage.local.set({ slotRun: { key: todayStr() + label, mode: S.runMode, at: Date.now() } });
  if (S.pageMode === 'rotate') {
    const rr = await rotateRun(true);
    if (rr.limitedAll) setStatus('Xong mốc ' + label + ': mọi page đã đủ ' + S.dailyLimit + ' bài hôm nay.', '');
    else setStatus('Xong mốc ' + label + (rr.ok ? ': đã có 1 lượt đăng thành công.' : ': chưa page nào đăng được.'), rr.ok ? '' : 'err');
  } else await runCycleSafe();
  await chrome.storage.local.remove('slotRun');
  await checkOut();
}

async function schedulerLoop(times) {
  const fired = new Set();
  const start = new Date();
  const startMin = start.getHours() * 60 + start.getMinutes();
  for (const t of times) if (toMin(t) < startMin) fired.add(dayKey(start) + t);
  log('Hẹn giờ: ' + times.join(', ') + '. Giữ tab này mở.', 'ok');
  // Mốc đang chạy dở khi bị ngắt (tắt máy, mất điện): chạy tiếp ngay
  const sr = (await chrome.storage.local.get('slotRun')).slotRun;
  if (sr && sr.key && sr.mode === 'schedule' && sr.key.slice(0, 10) === dayKey(start)) {
    const label = sr.key.slice(10);
    fired.add(sr.key);
    log('Chạy tiếp mốc ' + label + ' đang làm dở trước khi bị ngắt', 'warn');
    await runSlot(label);
  }
  while (!run.stop) {
    const now = new Date();
    const dk = dayKey(now);
    const mins = now.getHours() * 60 + now.getMinutes();
    const due = times.filter((t) => !fired.has(dk + t) && toMin(t) <= mins && mins - toMin(t) < 30);
    if (due.length) {
      fired.add(dk + due[0]);
      if (!inActive()) { log('Mốc ' + due[0] + ' nằm ngoài giờ hoạt động, bỏ qua', 'warn'); continue; }
      log('Đến mốc ' + due[0] + ', chạy vòng mới');
      await runSlot(due[0]);
    } else {
      const next = times.find((t) => !fired.has(dk + t) && toMin(t) > mins) || (times[0] + ' (ngày mai)');
      setStatus('Đang chờ mốc giờ kế tiếp: ' + next, '');
      await refreshFolderThrottled();
      await sleep(10000);
    }
  }
}

// Chạy cách nhau: chạy một lượt ngay, rồi cứ sau N phút (tính từ lúc bắt đầu lượt trước) chạy tiếp.
async function intervalLoop(min) {
  const ms = min * 60000;
  log('Chạy cách nhau mỗi ' + min + ' phút (tính từ lúc xong lượt đăng gần nhất). Giữ tab này mở.', 'ok');
  const sr = (await chrome.storage.local.get('slotRun')).slotRun;
  if (sr && sr.mode === 'interval' && Date.now() - (sr.at || 0) < 6 * 3600 * 1000) {
    if (inActive()) {
      log('Chạy tiếp lượt đang làm dở trước khi bị ngắt', 'warn');
      await runSlot(sr.key.slice(10));
    } else {
      log('Lượt dở dang nằm ngoài giờ hoạt động (' + S.activeFrom + ' đến ' + S.activeTo + '), bỏ qua', 'warn');
      await chrome.storage.local.remove('slotRun');
    }
  }
  while (!run.stop) {
    await waitActive();
    const t0 = Date.now();
    const d0 = new Date(t0);
    await runSlot(pad(d0.getHours()) + ':' + pad(d0.getMinutes()));
    const next = Date.now() + ms; // tính từ lúc xong lượt đăng gần nhất
    while (!run.stop && Date.now() < next) {
      const nd = new Date(next);
      setStatus('Đang chờ lần chạy kế tiếp lúc ' + pad(nd.getHours()) + ':' + pad(nd.getMinutes()), '');
      await refreshFolderThrottled();
      await sleep(Math.min(10000, Math.max(500, next - Date.now())));
    }
  }
}

/* ====================== bắt đầu / dừng ====================== */
function validate() {
  const errs = [];
  if (!dirHandle) errs.push('Chưa chọn thư mục video.');
  if (S.useNewDir && !newDirHandle) errs.push('Đã bật thư mục video mới nhưng chưa chọn thư mục.');
  if (!lines(S.pagesText).length) errs.push('Chưa nhập tên page.');
  if (S.coverMode === 'fixed' && !fixed.cover) errs.push('Ảnh bìa: đã chọn ảnh cố định nhưng chưa chọn ảnh.');
  if (S.card2Mode === 'fixed' && !fixed.card2) errs.push('Ảnh Card 2: đã chọn ảnh cố định nhưng chưa chọn ảnh.');
  if (S.useActive && (hmMin(S.activeFrom) === null || hmMin(S.activeTo) === null)) errs.push('Giờ hoạt động nhập sai.');
  if (S.runMode === 'schedule') {
    const t = parseTimes(S.timesText);
    if (!t.ok.length) errs.push('Chưa nhập mốc giờ hợp lệ (ví dụ 08:00).');
    if (t.bad.length) errs.push('Mốc giờ sai định dạng: ' + t.bad.join(', ') + ' (cần dạng 08:00).');
  }
  return errs;
}

function setRunning(on) {
  run.active = on;
  $('btnStart').disabled = on;
  $('btnStop').disabled = !on;
}

async function onStart() {
  readUI(); saveSettings();
  hideBanner();
  if (dirHandle) {
    try { await dirHandle.requestPermission({ mode: 'read' }); } catch (e) { /* kiểm tra bên dưới */ }
    await refreshFolderInfo();
  }
  const errs = validate();
  if (dirHandle && (await dirHandle.queryPermission({ mode: 'read' })) !== 'granted') errs.push('Chưa cấp quyền đọc thư mục video.');
  if (S.moveFailed) {
    let okDir = false;
    try { okDir = await ensureFailDir(); } catch (e) { errs.push('Không tạo được thư mục "' + FAIL_DIR_NAME + '": ' + e.message); okDir = true; }
    if (!okDir) errs.push('Chưa có quyền ghi thư mục video để tạo thư mục "' + FAIL_DIR_NAME + '". Bấm Bắt đầu lại và chọn Cho phép.');
    else if (failDirHandle) log('Thư mục video lỗi: "' + FAIL_DIR_NAME + '" (nằm trong thư mục video)', 'ok');
  }
  if (S.useNewDir && newDirHandle) {
    try { await newDirHandle.requestPermission({ mode: 'readwrite' }); } catch (e) { /* kiểm tra bên dưới */ }
    if (!(await hasRW(newDirHandle))) errs.push('Chưa cấp quyền ghi cho thư mục video mới. Bấm Bắt đầu lại và chọn Cho phép.');
    if (dirHandle) { try { await dirHandle.requestPermission({ mode: 'readwrite' }); } catch (e) { /* bỏ qua */ } }
  }
  if (errs.length) { showBanner(errs.join(' ')); setStatus('Chưa chạy được, xem thông báo màu đỏ.', 'err'); return; }

  try { await loadResultFile(); } catch (e) { log('Không đọc được ' + RESULT_FILE + ': ' + e.message, 'warn'); }
  try { await resolveInflight(); } catch (e) { log('Không xử lý được lần đăng dở trước đó: ' + e.message, 'warn'); }
  if (navigator.locks) {
    const got = await navigator.locks.request('vc-run', { ifAvailable: true }, async (lock) => {
      if (!lock) return false;
      await mainRun();
      return true;
    });
    if (!got) { showBanner('Đang có một cửa sổ Thanh Can code khác chạy rồi. Đóng cửa sổ thừa để tránh đăng trùng.'); setStatus('Không chạy: cửa sổ khác đang chạy.', 'err'); }
  } else await mainRun();
}

async function mainRun() {
  deadPages.clear();
  run.stop = false;
  setRunning(true);
  renderFailList([]);
  await chrome.storage.local.set({ runState: { running: true, at: Date.now() } });
  try {
    if (S.runMode === 'schedule') await schedulerLoop(parseTimes(S.timesText).ok);
    else if (S.runMode === 'interval') await intervalLoop(S.intervalMin);
    else if ((await waitActive(), await checkOut())) setStatus('Hết video: mọi page đã đăng hết video trong thư mục.', 'err');
    else {
      let info = '';
      if (S.pageMode === 'rotate') {
        const rr = await rotateRun(false);
        if (rr.limitedAll) info = 'mọi page đã đủ ' + S.dailyLimit + ' bài hôm nay';
        else info = 'đã chạy hết ' + lines(S.pagesText).length + ' page';
      } else {
        const rr = await runCycleSafe();
        if (rr.limited) info = 'mọi page đã đủ ' + S.dailyLimit + ' bài hôm nay';
      }
      if (!run.stop) {
        if (await checkOut()) setStatus('Hết video: mọi page đã đăng hết video trong thư mục.', 'err');
        else if (info) setStatus('Xong, ' + info + '.', '');
      }
    }
  } catch (e) {
    if (e instanceof Stop) { setStatus('Đã dừng.', ''); log('Đã dừng theo yêu cầu', 'warn'); }
    else if (e instanceof NickError) { setStatus('Dừng vì nick lỗi.', 'err'); }
    else { log('Lỗi không mong muốn: ' + e.message, 'err'); setStatus('Lỗi: ' + e.message, 'err'); }
  } finally {
    await chrome.storage.local.set({ runState: { running: false } });
    setRunning(false);
    refreshFolderInfo();
  }
}

function onStop() {
  run.stop = true;
  setStatus('Đang dừng...', 'busy');
}

/* ====================== sao chép nhật ký, xuất và nhập cài đặt ====================== */
async function copyLog() {
  const head = [
    'Thanh Can code, nhật ký lúc ' + nowStr() + ' ngày ' + todayStr(),
    'Trạng thái: ' + $('statusText').textContent,
    'Cài đặt: chạy=' + S.runMode + ', page=' + S.pageMode + ', lỗi bỏ qua=' + S.maxFail + ', giới hạn ngày=' + S.dailyLimit + ', giờ hoạt động=' + (S.useActive ? S.activeFrom + '-' + S.activeTo : 'tắt') + ', cách nhau=' + S.intervalMin + ' phút',
    '----------------------------------------',
  ];
  const text = head.concat(logBuf).join('\n');
  try {
    await navigator.clipboard.writeText(text);
    $('copyInfo').textContent = 'Đã sao chép ' + logBuf.length + ' dòng nhật ký. Dán (Ctrl+V) gửi cho người hỗ trợ.';
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); $('copyInfo').textContent = 'Đã sao chép nhật ký.'; } catch (e2) { $('copyInfo').textContent = 'Không sao chép được: ' + e2.message; }
    ta.remove();
  }
}

async function exportSettings() {
  readUI();
  const images = {};
  for (const slot of ['cover', 'card2']) {
    const f = fixed[slot];
    if (f && f.blob) images[slot] = { name: f.name, type: f.blob.type || 'image/jpeg', b64: await blobToB64(f.blob) };
  }
  const data = {
    app: 'thanh-can-code', version: 2, savedAt: nowStr() + ' ' + todayStr(),
    settings: S,
    extra: { stats, history, state, failedVideos, videoFails, firstSeen, oldBefore, dailyLog, pendingLines, pageBad },
    folders: { video: dirHandle ? dirHandle.name : '', newVideo: newDirHandle ? newDirHandle.name : '' },
    images,
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
  const a = document.createElement('a');
  a.href = url; a.download = 'thanh-can-code-sao-luu-' + instTag().replace(/\s+/g, '-') + '-' + todayStr() + '.json';
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  log('Đã xuất sao lưu toàn bộ ra file ' + a.download + ' (trong thư mục Tải xuống): cài đặt, thống kê, lịch sử đăng, ảnh cố định', 'ok');
}

async function importSettings(ev) {
  const f = ev.target.files[0];
  ev.target.value = '';
  if (!f) return;
  try {
    const data = JSON.parse(await f.text());
    if (!data || data.app !== 'thanh-can-code' || typeof data.settings !== 'object') throw new Error('không phải file sao lưu của Thanh Can code');
    S = { ...DEFAULTS, ...data.settings, quiet: false };
    if (!data.settings.instName) S.instName = ''; // file không có tên thì để tool tự đặt
    const ex = data.extra || {};
    if (ex.stats) stats = ex.stats;
    if (ex.history) history = ex.history;
    if (ex.state) state = ex.state;
    if (ex.failedVideos) failedVideos = ex.failedVideos;
    if (ex.videoFails) videoFails = ex.videoFails;
    if (ex.firstSeen) firstSeen = ex.firstSeen;
    if (typeof ex.oldBefore === 'number') oldBefore = ex.oldBefore;
    if (ex.dailyLog) dailyLog = ex.dailyLog;
    if (Array.isArray(ex.pendingLines)) pendingLines = ex.pendingLines;
    if (ex.pageBad) pageBad = ex.pageBad;
    for (const slot of ['cover', 'card2']) {
      const im = (data.images || {})[slot];
      if (!im) continue;
      const bin = atob(im.b64), u = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
      fixed[slot] = { blob: new Blob([u], { type: im.type }), name: im.name };
      await idbSet('fixed-' + slot, fixed[slot]);
      $(slot + 'FileName').textContent = 'Đã chọn: ' + im.name;
    }
    applyUI();
    readUI();
    await chrome.storage.local.set({ settings: S, stats, history, state, failedVideos, videoFails, firstSeen, oldBefore, oldBeforeV: 2, dailyLog, pendingLines, pageBad });
    updateResultFileName();
    renderStats(); renderFailVideos(); renderDaily();
    log('Đã nhập sao lưu từ file ' + f.name + ' (lưu lúc ' + (data.savedAt || '?') + '). Tên extension: ' + instTag() + ', file lịch sử: ' + RESULT_FILE + '. Việc còn lại: bấm "Chọn thư mục video" chọn lại thư mục cũ.' + (data.extra ? '' : ' File này là bản cũ, chỉ có cài đặt.'), 'ok');
    if (dirHandle) await refreshDaily();
    // Chrome không cho đọc đường dẫn thật nên file sao lưu chỉ nhớ TÊN thư mục; mở sẵn hộp chọn để bạn bấm chọn lại.
    const fo = data.folders || {};
    if (fo.video || fo.newVideo) {
      const need = [];
      if (fo.video) need.push('thư mục video "' + fo.video + '"');
      if (S.useNewDir && fo.newVideo) need.push('thư mục video mới "' + fo.newVideo + '"');
      if (need.length) {
        showBanner('Chọn lại ' + need.join(' và ') + ' (Chrome không cho lưu đường dẫn thật, chỉ nhớ được tên).');
        if (fo.video && !dirHandle) await pickFolder();
        if (S.useNewDir && fo.newVideo && !newDirHandle) await pickNewFolder();
      }
    }
  } catch (e) {
    showBanner('Không nhập được sao lưu: ' + e.message);
  }
}

/* ====================== cập nhật từ GitHub ====================== */
const UPDATE_BASE = 'https://raw.githubusercontent.com/ThanhCan1997/thanh-can-code/main/';
const curVer = () => chrome.runtime.getManifest().version;
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
let updInfo = null;
async function checkUpdate(manual) {
  const el = $('updInfo');
  try {
    const r = await fetch(UPDATE_BASE + 'version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    updInfo = await r.json();
    if (cmpVer(updInfo.version, curVer()) > 0) {
      el.textContent = 'Đang dùng bản ' + curVer() + '. Có bản mới ' + updInfo.version + (updInfo.note ? ': ' + updInfo.note : '') + '.';
      $('btnDoUpd').hidden = false;
    } else {
      el.textContent = 'Đang dùng bản ' + curVer() + ', là bản mới nhất.';
      $('btnDoUpd').hidden = true;
    }
  } catch (e) { el.textContent = 'Bản ' + curVer() + '.' + (manual ? ' Không kiểm tra được bản mới: ' + e.message : ''); }
}
async function doUpdate() {
  if (run.active) { showBanner('Bấm Dừng trước rồi hãy cập nhật.'); return; }
  if (!updInfo) await checkUpdate(true);
  if (!updInfo || cmpVer(updInfo.version, curVer()) <= 0) return;
  const el = $('updInfo');
  try {
    let h = null;
    try { h = (await idbGet('extdir')) || null; } catch (e) { h = null; }
    if (h && (await h.requestPermission({ mode: 'readwrite' })) !== 'granted') h = null;
    if (!h) {
      h = await window.showDirectoryPicker({ mode: 'readwrite', id: 'vc-extdir' });
      let ok = false;
      try { const m = JSON.parse(await (await (await h.getFileHandle('manifest.json')).getFile()).text()); ok = m.name === chrome.runtime.getManifest().name && m.manifest_version === 3; } catch (e) { ok = false; }
      if (!ok) { showBanner('Thư mục này không phải thư mục cài Thanh Can code (không thấy manifest.json đúng). Mở chrome://extensions, bấm Chi tiết của extension để xem đường dẫn thư mục.'); return; }
      await idbSet('extdir', h);
    }
    el.textContent = 'Đang tải bản ' + updInfo.version + '...';
    const r = await fetch(UPDATE_BASE + (updInfo.zip || 'update.zip') + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('tải file zip lỗi HTTP ' + r.status);
    const zip = await JSZip.loadAsync(await r.arrayBuffer());
    const names = Object.keys(zip.files).filter((n) => !zip.files[n].dir);
    if (!names.includes('manifest.json') || !names.includes('app.js')) throw new Error('file zip thiếu manifest.json hoặc app.js');
    for (const n of names) {
      const parts = n.split('/');
      if (parts.some((p) => p === '..' || p === '')) continue;
      let d = h;
      for (const p of parts.slice(0, -1)) d = await d.getDirectoryHandle(p, { create: true });
      const w = await (await d.getFileHandle(parts[parts.length - 1], { create: true })).createWritable();
      await w.write(await zip.files[n].async('uint8array'));
      await w.close();
    }
    await chrome.storage.local.set({ afterUpdate: true });
    el.textContent = 'Đã cập nhật lên bản ' + updInfo.version + ', đang khởi động lại...';
    setTimeout(() => chrome.runtime.reload(), 800);
  } catch (e) {
    if (e.name === 'AbortError') return;
    el.textContent = 'Cập nhật lỗi: ' + e.message;
    log('Cập nhật lỗi: ' + e.message, 'err');
  }
}

/* ====================== khởi động ====================== */
async function init() {
  const r = await chrome.storage.local.get(['settings', 'stats', 'history', 'state', 'failedVideos', 'videoFails', 'dailyLog', 'pendingLines', 'runState', 'firstSeen', 'oldBefore', 'oldBeforeV', 'pageBad']);
  pageBad = r.pageBad || {};
  S = { ...DEFAULTS, ...(r.settings || {}) };
  S.quiet = false; // đã bỏ chế độ chạy ngầm: luôn bật tab lên như cũ
  stats = r.stats || stats;
  history = r.history || {};
  state = r.state || state;
  failedVideos = r.failedVideos || [];
  videoFails = r.videoFails || {};
  firstSeen = r.firstSeen || {};
  if (r.oldBeforeV === 2 && typeof r.oldBefore === 'number') oldBefore = r.oldBefore;
  else {
    // Video có sẵn từ đầu là video cũ (đăng ngẫu nhiên). Chỉ video bỏ vào SAU lần quét đầu tiên mới là video mới.
    const seen = Object.values(firstSeen);
    oldBefore = seen.length ? Math.max(...seen) : -1; // -1: chưa quét lần nào, lần quét đầu sẽ đặt mốc
    chrome.storage.local.set({ oldBefore, oldBeforeV: 2 });
  }
  dailyLog = r.dailyLog || {};
  pendingLines = r.pendingLines || [];
  applyUI();
  updateResultFileName();
  renderDaily();
  renderStats();
  renderFailVideos();

  try { dirHandle = (await idbGet('dir')) || null; } catch (e) { dirHandle = null; }
  try { newDirHandle = (await idbGet('newdir')) || null; } catch (e) { newDirHandle = null; }
  for (const slot of ['cover', 'card2']) {
    try { fixed[slot] = (await idbGet('fixed-' + slot)) || null; } catch (e) { fixed[slot] = null; }
    if (fixed[slot]) $(slot + 'FileName').textContent = 'Đã chọn: ' + fixed[slot].name;
  }
  await refreshFolderInfo();
  await refreshFailInfo();
  try { if (dirHandle && (await dirHandle.queryPermission({ mode: 'read' })) === 'granted') await refreshDaily(); } catch (e) { /* bỏ qua */ }

  for (const id of ['pagesText', 'coverRatio', 'card2Ratio', 'title1', 'title2', 'linksText', 'timesText', 'checkNick', 'moveFailed', 'maxFail', 'dailyLimit', 'instName', 'useNewDir', 'newMax', 'intervalMin', 'useActive', 'activeFrom', 'activeTo']) {
    $(id).addEventListener('input', onChange);
    $(id).addEventListener('change', onChange);
  }
  for (const n of ['pageMode', 'coverMode', 'card2Mode', 'runMode', 'alertMode', 'soundFile']) {
    document.querySelectorAll(`input[name="${n}"]`).forEach((el) => el.addEventListener('change', onChange));
  }
  bindFixedImage('cover', 'coverFile', 'coverFileName');
  bindFixedImage('card2', 'card2File', 'card2FileName');

  $('btnFolder').addEventListener('click', pickFolder);
  $('btnNewFolder').addEventListener('click', pickNewFolder);
  const bumpNew = (d) => { $('newMax').value = Math.min(50, Math.max(1, (parseInt($('newMax').value, 10) || 3) + d)); onChange(); };
  $('btnNewMinus').addEventListener('click', () => bumpNew(-1));
  $('btnNewPlus').addEventListener('click', () => bumpNew(1));
  refreshNewInfo();
  $('btnPerm').addEventListener('click', regrantPermission);
  const bump = (d) => { $('maxFail').value = Math.min(20, Math.max(1, (parseInt($('maxFail').value, 10) || 4) + d)); onChange(); };
  $('btnFailMinus').addEventListener('click', () => bump(-1));
  $('btnFailPlus').addEventListener('click', () => bump(1));
  const bumpDay = (d) => { $('dailyLimit').value = Math.min(200, Math.max(0, (parseInt($('dailyLimit').value, 10) || 0) + d)); onChange(); };
  $('btnDaily').addEventListener('click', refreshDaily);
  $('btnCopyLog').addEventListener('click', copyLog);
  $('btnExport').addEventListener('click', exportSettings);
  $('btnCheckUpd').addEventListener('click', () => checkUpdate(true));
  $('btnDoUpd').addEventListener('click', doUpdate);
  checkUpdate(false);
  $('importFile').addEventListener('change', importSettings);
  $('btnDayMinus').addEventListener('click', () => bumpDay(-1));
  $('btnDayPlus').addEventListener('click', () => bumpDay(1));
  document.querySelectorAll('.btnListen').forEach((b) => b.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); playNickSound(1, b.dataset.id); }));
  $('btnStart').addEventListener('click', onStart);
  $('btnStop').addEventListener('click', onStop);
  $('btnResetStats').addEventListener('click', async () => {
    if (!confirm('Xoá toàn bộ thống kê?')) return;
    stats = { success: 0, fail: 0, runs: 0, byPage: {} };
    await saveStats(); renderStats();
  });
  $('btnClearFailVideos').addEventListener('click', async () => { failedVideos = []; await saveFailedVideos(); renderFailVideos(); });
  $('btnResetHistory').addEventListener('click', async () => {
    if (!confirm('Xoá lịch sử video đã đăng? Sau đó video cũ có thể được đăng lại.')) return;
    history = {}; await chrome.storage.local.set({ history });
    try { if (dirHandle && (await hasRW(dirHandle))) await writeResultText(''); } catch (e) { /* bỏ qua */ }
    log('Đã xoá lịch sử video đã đăng (kể cả file ' + RESULT_FILE + ')', 'warn');
  });

  // Lần chạy trước bị ngắt giữa chừng (tắt máy, mất điện, đóng trình duyệt): tự chạy tiếp nếu đã có quyền thư mục
  const rs = r.runState;
  if (rs && rs.running) {
    const fresh = Date.now() - (rs.at || 0) < 12 * 3600 * 1000;
    let rw = false;
    try { rw = !!dirHandle && (await hasRW(dirHandle)); } catch (e) { rw = false; }
    if (fresh && rw) { log('Lần chạy trước bị ngắt giữa chừng, tự chạy tiếp (tool nhớ đã đăng gì rồi, không đăng trùng)', 'warn'); setTimeout(onStart, 2000); }
    else showBanner('Lần chạy trước bị ngắt giữa chừng. Bấm "Bắt đầu chạy" để chạy tiếp, tool nhớ đã đăng gì rồi nên không đăng trùng.');
  }

  setInterval(() => { const d = dayStats(); if (d.day !== lastRenderDay) { lastRenderDay = d.day; renderStats(); renderDaily(); } }, 30000);

  window.addEventListener('beforeunload', (e) => { if (run.active) { e.preventDefault(); e.returnValue = ''; } });
}

init();
