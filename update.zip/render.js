/* render.js: tăng tốc video ngay trong Chrome (WebCodecs) rồi xuất ra mp4 trong bộ nhớ.
   Không lưu gì ra đĩa. Dùng: const out = await TCRender.speedUp(file, 1.1, (p) => {...});  out là File mp4. */
(function (root) {
  'use strict';

  /* ---------- ghi file mp4 ---------- */
  const enc = new TextEncoder();
  const be32 = (n) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
  const be16 = (n) => [(n >>> 8) & 255, n & 255];
  const cat = (parts) => {
    let len = 0;
    const ps = parts.map((p) => (p instanceof Uint8Array ? p : Uint8Array.from(p)));
    for (const p of ps) len += p.length;
    const out = new Uint8Array(len);
    let o = 0;
    for (const p of ps) { out.set(p, o); o += p.length; }
    return out;
  };
  const box = (type, ...payloads) => {
    const body = cat(payloads);
    return cat([be32(body.length + 8), enc.encode(type), body]);
  };
  const fbox = (type, version, flags, ...payloads) => box(type, [version, (flags >> 16) & 255, (flags >> 8) & 255, flags & 255], ...payloads);
  const MATRIX = [].concat(be32(0x00010000), be32(0), be32(0), be32(0), be32(0x00010000), be32(0), be32(0), be32(0), be32(0x40000000));

  function sampleTables(samples, timescale, usToTs, base) {
    // samples: [{data, ts, key}], đã xếp theo thời gian. base.offsets: vị trí từng mẫu trong file
    const n = samples.length;
    const deltas = [];
    for (let i = 0; i < n; i++) {
      if (i + 1 < n) deltas.push(Math.max(1, Math.round(usToTs(samples[i + 1].ts) - usToTs(samples[i].ts))));
      else deltas.push(deltas.length ? deltas[deltas.length - 1] : 1);
    }
    const stts = [];
    for (const d of deltas) {
      const last = stts[stts.length - 1];
      if (last && last[1] === d) last[0]++; else stts.push([1, d]);
    }
    const sttsBox = fbox('stts', 0, 0, be32(stts.length), ...stts.map((e) => cat([be32(e[0]), be32(e[1])])));
    const stscBox = fbox('stsc', 0, 0, be32(1), be32(1), be32(1), be32(1));
    const stszBox = fbox('stsz', 0, 0, be32(0), be32(n), ...samples.map((s) => be32(s.data.length)));
    const stcoBox = fbox('stco', 0, 0, be32(n), ...base.offsets.map((o) => be32(o)));
    const keys = [];
    samples.forEach((s, i) => { if (s.key) keys.push(i + 1); });
    const stssBox = fbox('stss', 0, 0, be32(keys.length), ...keys.map((k) => be32(k)));
    const total = deltas.reduce((a, b) => a + b, 0);
    return { stts: sttsBox, stsc: stscBox, stsz: stszBox, stco: stcoBox, stss: stssBox, total };
  }

  function trak(id, kind, entry, samples, timescale, usToTs, offsets, dims) {
    const t = sampleTables(samples, timescale, usToTs, { offsets });
    const movieDur = Math.round((t.total / timescale) * 1000);
    const tkhd = fbox('tkhd', 0, 3, be32(0), be32(0), be32(id), be32(0), be32(movieDur), be32(0), be32(0),
      be16(0), be16(0), be16(kind === 'soun' ? 0x0100 : 0), be16(0), MATRIX, be32(dims ? dims.w << 16 : 0), be32(dims ? dims.h << 16 : 0));
    const mdhd = fbox('mdhd', 0, 0, be32(0), be32(0), be32(timescale), be32(t.total), be16(0x55c4), be16(0));
    const hdlr = fbox('hdlr', 0, 0, be32(0), enc.encode(kind), be32(0), be32(0), be32(0), enc.encode(kind === 'vide' ? 'VideoHandler' : 'SoundHandler'), [0]);
    const mhd = kind === 'vide' ? fbox('vmhd', 0, 1, be16(0), be16(0), be16(0), be16(0)) : fbox('smhd', 0, 0, be16(0), be16(0));
    const dinf = box('dinf', fbox('dref', 0, 0, be32(1), fbox('url ', 0, 1)));
    const stsd = fbox('stsd', 0, 0, be32(1), entry);
    const stbl = box('stbl', stsd, t.stts, ...(kind === 'vide' ? [t.stss] : []), t.stsc, t.stsz, t.stco);
    const minf = box('minf', mhd, dinf, stbl);
    return { box: box('trak', tkhd, box('mdia', mdhd, hdlr, minf)), movieDur };
  }

  function videoEntry(w, h, avcC) {
    const name = new Uint8Array(32);
    return box('avc1', [0, 0, 0, 0, 0, 0], be16(1), be16(0), be16(0), be32(0), be32(0), be32(0), be16(w), be16(h),
      be32(0x00480000), be32(0x00480000), be32(0), be16(1), name, be16(0x0018), be16(0xffff), box('avcC', avcC));
  }
  function audioEntryHead(ch, rate) {
    return [[0, 0, 0, 0, 0, 0], be16(1), be32(0), be32(0), be16(ch), be16(16), be16(0), be16(0), be32(rate * 65536 > 4294967295 ? 0 : rate * 65536)];
  }
  function aacEntry(ch, rate, asc) {
    const dec = cat([[0x05, asc.length], asc]);
    const decCfgBody = cat([[0x40, 0x15, 0, 0, 0], be32(0), be32(0), dec]);
    const decCfg = cat([[0x04, decCfgBody.length], decCfgBody]);
    const esBody = cat([[0, 1, 0], decCfg, [0x06, 0x01, 0x02]]);
    const es = cat([[0x03, esBody.length], esBody]);
    return box('mp4a', ...audioEntryHead(ch, rate), fbox('esds', 0, 0, es));
  }
  function opusEntry(ch, rate, head) {
    let pre = 312, inRate = rate;
    if (head && head.length >= 19) { pre = head[10] | (head[11] << 8); inRate = (head[12] | (head[13] << 8) | (head[14] << 16) | (head[15] << 24)) >>> 0; }
    return box('Opus', ...audioEntryHead(ch, 48000), box('dOps', [0, ch], be16(pre), be32(inRate), be16(0), [0]));
  }

  // video: {w,h,avcC,samples:[{data,ts,key}], timescale}; audio: null hoặc {kind:'aac'|'opus',ch,rate,config,samples:[{data,ts}]}
  function muxMp4(video, audio) {
    const all = [];
    video.samples.forEach((s, i) => all.push({ tr: 'v', i, ts: s.ts, data: s.data }));
    if (audio) audio.samples.forEach((s, i) => all.push({ tr: 'a', i, ts: s.ts, data: s.data }));
    all.sort((a, b) => a.ts - b.ts || (a.tr === 'v' ? -1 : 1));
    const ftyp = box('ftyp', enc.encode('isom'), be32(512), enc.encode('isom'), enc.encode('iso2'), enc.encode('avc1'), enc.encode('mp41'));
    const build = (mdatStart) => {
      const vOff = new Array(video.samples.length), aOff = audio ? new Array(audio.samples.length) : [];
      let pos = mdatStart;
      for (const e of all) { (e.tr === 'v' ? vOff : aOff)[e.i] = pos; pos += e.data.length; }
      const vt = trak(1, 'vide', videoEntry(video.w, video.h, video.avcC), video.samples, video.timescale, (us) => (us * video.timescale) / 1e6, vOff, { w: video.w, h: video.h });
      const parts = [vt.box];
      let dur = vt.movieDur;
      if (audio) {
        const entry = audio.kind === 'aac' ? aacEntry(audio.ch, audio.rate, audio.config) : opusEntry(audio.ch, audio.rate, audio.config);
        const at = trak(2, 'soun', entry, audio.samples, audio.rate, (us) => (us * audio.rate) / 1e6, aOff, null);
        parts.push(at.box);
        dur = Math.max(dur, at.movieDur);
      }
      const mvhd = fbox('mvhd', 0, 0, be32(0), be32(0), be32(1000), be32(dur), be32(0x00010000), be16(0x0100), be16(0), be32(0), be32(0), MATRIX, new Uint8Array(24), be32(audio ? 3 : 2));
      return box('moov', mvhd, ...parts);
    };
    const moov0 = build(0);
    const mdatStart = ftyp.length + moov0.length + 8;
    const moov = build(mdatStart);
    let total = 0;
    for (const e of all) total += e.data.length;
    return new Blob([ftyp, moov, cat([be32(total + 8), enc.encode('mdat')]), ...all.map((e) => e.data)], { type: 'video/mp4' });
  }

  /* ---------- mã hoá bằng WebCodecs ---------- */
  const FPS = 30;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const waitEvent = (el, ok, bad, ms) => new Promise((res, rej) => {
    let done = false;
    const fin = (f, v) => { if (done) return; done = true; clearTimeout(tm); el.removeEventListener(ok, onOk); if (bad) el.removeEventListener(bad, onBad); f(v); };
    const onOk = () => fin(res);
    const onBad = () => fin(rej, new Error('video lỗi khi đọc'));
    const tm = setTimeout(() => fin(res, 'timeout'), ms || 8000);
    el.addEventListener(ok, onOk);
    if (bad) el.addEventListener(bad, onBad);
  });

  async function pickVideoCodec(w, h, bitrate) {
    for (const codec of ['avc1.64002A', 'avc1.4D402A', 'avc1.42E01F']) {
      const cfg = { codec, width: w, height: h, bitrate, framerate: FPS, avc: { format: 'avc' } };
      try { const s = await VideoEncoder.isConfigSupported(cfg); if (s && s.supported) return cfg; } catch (e) { /* thử tiếp */ }
    }
    throw new Error('Chrome không mã hoá được H.264 trên máy này');
  }

  async function encodeAudio(file, factor, onProgress) {
    if (typeof AudioEncoder === 'undefined') return null;
    let ab;
    try {
      const buf = await file.arrayBuffer();
      ab = await new OfflineAudioContext(2, 1, 48000).decodeAudioData(buf);
    } catch (e) { return null; } // video không có tiếng hoặc Chrome không đọc được tiếng
    const ch = Math.min(2, ab.numberOfChannels);
    const rate = 48000;
    const len = Math.max(1, Math.ceil(ab.length / factor));
    const oc = new OfflineAudioContext(ch, len, rate);
    const src = oc.createBufferSource();
    src.buffer = ab;
    src.playbackRate.value = factor;
    src.connect(oc.destination);
    src.start();
    const pcm = await oc.startRendering();
    let kind = 'aac';
    let cfg = { codec: 'mp4a.40.2', sampleRate: rate, numberOfChannels: ch, bitrate: 128000, aac: { format: 'aac' } };
    let sup = false;
    try { sup = (await AudioEncoder.isConfigSupported(cfg)).supported; } catch (e) { sup = false; }
    if (!sup) {
      kind = 'opus';
      cfg = { codec: 'opus', sampleRate: rate, numberOfChannels: ch, bitrate: 96000 };
      try { sup = (await AudioEncoder.isConfigSupported(cfg)).supported; } catch (e) { sup = false; }
      if (!sup) return null;
    }
    const samples = [];
    let config = null;
    const aenc = new AudioEncoder({
      output: (chunk, meta) => {
        if (!config && meta && meta.decoderConfig && meta.decoderConfig.description) config = new Uint8Array(meta.decoderConfig.description instanceof ArrayBuffer ? meta.decoderConfig.description : meta.decoderConfig.description.buffer.slice(meta.decoderConfig.description.byteOffset, meta.decoderConfig.description.byteOffset + meta.decoderConfig.description.byteLength));
        const d = new Uint8Array(chunk.byteLength);
        chunk.copyTo(d);
        samples.push({ data: d, ts: chunk.timestamp });
      },
      error: (e) => { aenc.err = e; },
    });
    aenc.configure(cfg);
    const BLOCK = 4800;
    const chans = [];
    for (let c = 0; c < ch; c++) chans.push(pcm.getChannelData(c));
    for (let off = 0; off < pcm.length; off += BLOCK) {
      const n = Math.min(BLOCK, pcm.length - off);
      const data = new Float32Array(n * ch);
      for (let c = 0; c < ch; c++) data.set(chans[c].subarray(off, off + n), c * n);
      const ad = new AudioData({ format: 'f32-planar', sampleRate: rate, numberOfFrames: n, numberOfChannels: ch, timestamp: Math.round((off * 1e6) / rate), data });
      aenc.encode(ad);
      ad.close();
      if (aenc.encodeQueueSize > 8) await waitEvent(aenc, 'dequeue', null, 1000);
      if (aenc.err) throw aenc.err;
    }
    await aenc.flush();
    aenc.close();
    if (!samples.length) return null;
    if (kind === 'aac' && !config) return null;
    if (onProgress) onProgress(0.15);
    return { kind, ch, rate, config, samples };
  }

  async function speedUp(file, factor, onProgress) {
    if (typeof VideoEncoder === 'undefined' || typeof VideoFrame === 'undefined') throw new Error('Chrome này không có WebCodecs');
    const report = (p) => { try { if (onProgress) onProgress(Math.min(1, p)); } catch (e) { /* bỏ qua */ } };
    const audio = await encodeAudio(file, factor, report);

    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.muted = true;
    v.preload = 'auto';
    v.playsInline = true;
    try {
      v.src = url;
      await waitEvent(v, 'loadeddata', 'error', 20000);
      if (!v.videoWidth || !v.duration || !isFinite(v.duration)) throw new Error('Chrome không đọc được video này');
      let W = v.videoWidth, H = v.videoHeight;
      const maxSide = 1920;
      if (Math.max(W, H) > maxSide) { const k = maxSide / Math.max(W, H); W = Math.round(W * k); H = Math.round(H * k); }
      W &= ~1; H &= ~1;
      const dur = v.duration;
      const N = Math.max(1, Math.floor((dur / factor) * FPS));
      const bitrate = Math.round(Math.min(8e6, Math.max(2e6, W * H * FPS * 0.12)));
      const cfg = await pickVideoCodec(W, H, bitrate);
      const samples = [];
      let avcC = null;
      let verr = null;
      const venc = new VideoEncoder({
        output: (chunk, meta) => {
          if (!avcC && meta && meta.decoderConfig && meta.decoderConfig.description) {
            const d = meta.decoderConfig.description;
            avcC = new Uint8Array(d instanceof ArrayBuffer ? d.slice(0) : d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength));
          }
          const data = new Uint8Array(chunk.byteLength);
          chunk.copyTo(data);
          samples.push({ data, ts: chunk.timestamp, key: chunk.type === 'key' });
        },
        error: (e) => { verr = e; },
      });
      venc.configure(cfg);
      const canvas = new OffscreenCanvas(W, H);
      const ctx = canvas.getContext('2d');
      for (let i = 0; i < N; i++) {
        const t = Math.min(Math.max(0.01, (i * factor) / FPS), Math.max(0.01, dur - 0.05));
        v.currentTime = t;
        await waitEvent(v, 'seeked', 'error', 8000);
        ctx.drawImage(v, 0, 0, W, H);
        const frame = new VideoFrame(canvas, { timestamp: Math.round((i * 1e6) / FPS), duration: Math.round(1e6 / FPS) });
        venc.encode(frame, { keyFrame: i % (FPS * 2) === 0 });
        frame.close();
        if (verr) throw verr;
        if (venc.encodeQueueSize > 6) await waitEvent(venc, 'dequeue', null, 1000);
        if (i % 15 === 0) report((audio ? 0.15 : 0) + (i / N) * (audio ? 0.8 : 0.95));
      }
      await venc.flush();
      venc.close();
      if (verr) throw verr;
      if (!samples.length || !avcC) throw new Error('mã hoá video không ra dữ liệu');
      const blob = muxMp4({ w: W, h: H, avcC, samples, timescale: FPS * 1000 }, audio);
      report(1);
      const name = (file.name || 'video.mp4').replace(/\.[^.]+$/, '') + '.mp4';
      return new File([blob], name, { type: 'video/mp4' });
    } finally {
      try { v.removeAttribute('src'); v.load(); } catch (e) { /* bỏ qua */ }
      URL.revokeObjectURL(url);
    }
  }

  root.TCRender = { speedUp, muxMp4 };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.TCRender;
})(typeof window !== 'undefined' ? window : globalThis);
