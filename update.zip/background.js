// Bấm biểu tượng extension: mở (hoặc chuyển tới) tab bảng điều khiển.
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('app.html');
  const tabs = await chrome.tabs.query({ url });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});

// Mở lại bảng điều khiển khi Chrome khởi động, nếu lần chạy trước bị ngắt giữa chừng (tắt máy, mất điện).
chrome.runtime.onStartup.addListener(() => {
  setTimeout(async () => {
    const { runState } = await chrome.storage.local.get('runState');
    if (!runState || !runState.running || Date.now() - (runState.at || 0) > 12 * 3600 * 1000) return;
    const url = chrome.runtime.getURL('app.html');
    const tabs = await chrome.tabs.query({ url });
    if (!tabs.length) await chrome.tabs.create({ url });
  }, 5000);
});

// Sau khi bấm "Cập nhật" trong tool, extension tự khởi động lại: mở lại bảng điều khiển.
chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason !== 'update') return;
  const { afterUpdate } = await chrome.storage.local.get('afterUpdate');
  if (!afterUpdate) return;
  await chrome.storage.local.remove('afterUpdate');
  await chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
});
